// src/components/UI.js
import React from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  ActivityIndicator, StyleSheet, Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, Typography, Spacing, Radius, Shadow } from '../utils/theme';

const { width } = Dimensions.get('window');

// ─── Gold Button ──────────────────────────────────────────────────────────────
export const GoldButton = ({ title, onPress, loading, outline, small, style }) => {
  if (outline) {
    return (
      <TouchableOpacity
        onPress={onPress}
        disabled={loading}
        activeOpacity={0.7}
        style={[styles.outlineBtn, small && styles.smallBtn, style]}
      >
        {loading
          ? <ActivityIndicator size="small" color={Colors.gold} />
          : <Text style={[styles.outlineBtnText, small && styles.smallBtnText]}>{title}</Text>
        }
      </TouchableOpacity>
    );
  }
  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={loading}
      activeOpacity={0.8}
      style={[styles.btnWrapper, small && styles.smallBtn, style]}
    >
      <LinearGradient
        colors={['#F0CB5A', '#D4AF37', '#A88A20']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[styles.btn, small && styles.smallBtnInner]}
      >
        {loading
          ? <ActivityIndicator size="small" color="#000" />
          : <Text style={[styles.btnText, small && styles.smallBtnText]}>{title}</Text>
        }
      </LinearGradient>
    </TouchableOpacity>
  );
};

// ─── Card ─────────────────────────────────────────────────────────────────────
export const Card = ({ children, style, glow }) => (
  <View style={[styles.card, glow && styles.cardGlow, style]}>
    {children}
  </View>
);

// ─── Input Field ──────────────────────────────────────────────────────────────
export const InputField = ({
  label, value, onChangeText, placeholder,
  secureTextEntry, keyboardType, icon, error, style,
}) => (
  <View style={[styles.inputWrapper, style]}>
    {label && <Text style={styles.inputLabel}>{label}</Text>}
    <View style={[styles.inputContainer, error && styles.inputError]}>
      {icon && <Text style={styles.inputIcon}>{icon}</Text>}
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={Colors.textMuted}
        secureTextEntry={secureTextEntry}
        keyboardType={keyboardType || 'default'}
        style={styles.input}
        autoCapitalize="none"
        autoCorrect={false}
      />
    </View>
    {error && <Text style={styles.errorText}>{error}</Text>}
  </View>
);

// ─── Badge ────────────────────────────────────────────────────────────────────
export const Badge = ({ text, type = 'default' }) => {
  const typeColors = {
    success:   { bg: Colors.successBg, text: Colors.success },
    danger:    { bg: Colors.dangerBg,  text: Colors.danger  },
    warning:   { bg: Colors.warningBg, text: Colors.warning },
    info:      { bg: Colors.infoBg,    text: Colors.info    },
    gold:      { bg: Colors.goldSubtle,text: Colors.gold    },
    default:   { bg: 'rgba(255,255,255,0.08)', text: Colors.textSecondary },
  };
  const c = typeColors[type] || typeColors.default;
  return (
    <View style={[styles.badge, { backgroundColor: c.bg }]}>
      <Text style={[styles.badgeText, { color: c.text }]}>{text}</Text>
    </View>
  );
};

// ─── Section Header ───────────────────────────────────────────────────────────
export const SectionHeader = ({ title, action, onAction }) => (
  <View style={styles.sectionHeader}>
    <Text style={styles.sectionTitle}>{title}</Text>
    {action && (
      <TouchableOpacity onPress={onAction}>
        <Text style={styles.sectionAction}>{action}</Text>
      </TouchableOpacity>
    )}
  </View>
);

// ─── Stat Card ────────────────────────────────────────────────────────────────
export const StatCard = ({ label, value, icon, color, change }) => (
  <Card style={styles.statCard}>
    <Text style={styles.statIcon}>{icon}</Text>
    <Text style={[styles.statValue, color && { color }]}>{value}</Text>
    <Text style={styles.statLabel}>{label}</Text>
    {change !== undefined && (
      <Text style={[styles.statChange, { color: change >= 0 ? Colors.success : Colors.danger }]}>
        {change >= 0 ? '▲' : '▼'} {Math.abs(change)}%
      </Text>
    )}
  </Card>
);

// ─── Divider ──────────────────────────────────────────────────────────────────
export const GoldDivider = () => (
  <LinearGradient
    colors={['transparent', Colors.gold, 'transparent']}
    start={{ x: 0, y: 0 }}
    end={{ x: 1, y: 0 }}
    style={styles.divider}
  />
);

// ─── Empty State ──────────────────────────────────────────────────────────────
export const EmptyState = ({ icon, title, subtitle }) => (
  <View style={styles.emptyState}>
    <Text style={styles.emptyIcon}>{icon || '📭'}</Text>
    <Text style={styles.emptyTitle}>{title || 'No data found'}</Text>
    {subtitle && <Text style={styles.emptySubtitle}>{subtitle}</Text>}
  </View>
);

// ─── Styles ───────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  // Button
  btnWrapper:    { borderRadius: Radius.md, overflow: 'hidden', ...Shadow.gold },
  btn:           { paddingVertical: 15, paddingHorizontal: 32, alignItems: 'center' },
  btnText:       { fontFamily: Typography.bold, fontSize: 15, color: '#000', letterSpacing: 1 },
  outlineBtn:    {
    borderWidth: 1.5, borderColor: Colors.gold,
    borderRadius: Radius.md, paddingVertical: 14,
    paddingHorizontal: 32, alignItems: 'center',
  },
  outlineBtnText:{ fontFamily: Typography.heading, fontSize: 15, color: Colors.gold, letterSpacing: 1 },
  smallBtn:      { borderRadius: Radius.sm },
  smallBtnInner: { paddingVertical: 10, paddingHorizontal: 20 },
  smallBtnText:  { fontSize: 13 },

  // Card
  card: {
    backgroundColor: Colors.backgroundCard,
    borderRadius: Radius.lg,
    padding: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.border,
    ...Shadow.card,
  },
  cardGlow: { borderColor: Colors.goldBorder, ...Shadow.gold },

  // Input
  inputWrapper:    { marginBottom: Spacing.md },
  inputLabel:      { fontFamily: Typography.heading, fontSize: 12, color: Colors.textSecondary, marginBottom: 6, letterSpacing: 0.8 },
  inputContainer: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderWidth: 1, borderColor: Colors.border,
    borderRadius: Radius.md, paddingHorizontal: 14,
  },
  inputError:     { borderColor: Colors.danger },
  inputIcon:      { fontSize: 18, marginRight: 10 },
  input:          { flex: 1, color: Colors.textPrimary, fontFamily: Typography.body, fontSize: 15, paddingVertical: 14 },
  errorText:      { fontFamily: Typography.caption, fontSize: 12, color: Colors.danger, marginTop: 4 },

  // Badge
  badge:     { paddingHorizontal: 10, paddingVertical: 4, borderRadius: Radius.full },
  badgeText: { fontFamily: Typography.heading, fontSize: 11, letterSpacing: 0.5 },

  // Section Header
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: Spacing.sm },
  sectionTitle:  { fontFamily: Typography.display, fontSize: 22, color: Colors.textPrimary },
  sectionAction: { fontFamily: Typography.heading, fontSize: 13, color: Colors.gold },

  // Stat Card
  statCard:   { flex: 1, alignItems: 'center', padding: Spacing.sm },
  statIcon:   { fontSize: 24, marginBottom: 6 },
  statValue:  { fontFamily: Typography.display, fontSize: 20, color: Colors.gold, marginBottom: 2 },
  statLabel:  { fontFamily: Typography.caption, fontSize: 11, color: Colors.textSecondary, textAlign: 'center' },
  statChange: { fontFamily: Typography.caption, fontSize: 11, marginTop: 2 },

  // Divider
  divider: { height: 1, marginVertical: Spacing.md },

  // Empty State
  emptyState:    { alignItems: 'center', paddingVertical: Spacing.xxl },
  emptyIcon:     { fontSize: 48, marginBottom: Spacing.md },
  emptyTitle:    { fontFamily: Typography.display, fontSize: 20, color: Colors.textSecondary, marginBottom: 8 },
  emptySubtitle: { fontFamily: Typography.body, fontSize: 14, color: Colors.textMuted, textAlign: 'center' },
});
