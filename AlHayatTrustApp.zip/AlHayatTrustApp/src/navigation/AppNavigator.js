// src/navigation/AppNavigator.js
import React from 'react';
import { View, Text, StyleSheet, Platform } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import SplashScreen       from '../screens/SplashScreen';
import LoginScreen        from '../screens/LoginScreen';
import RegisterScreen     from '../screens/RegisterScreen';
import HomeScreen         from '../screens/HomeScreen';
import PlansScreen        from '../screens/PlansScreen';
import DepositScreen      from '../screens/DepositScreen';
import WithdrawScreen     from '../screens/WithdrawScreen';
import ReferralScreen     from '../screens/ReferralScreen';
import ProfileScreen      from '../screens/ProfileScreen';
import TransactionsScreen from '../screens/TransactionsScreen';

import { Colors, Typography } from '../utils/theme';

const Stack  = createNativeStackNavigator();
const Tab    = createBottomTabNavigator();

const TAB_ICONS = {
  Home:    { active: '🏠', inactive: '🏡' },
  Plans:   { active: '📊', inactive: '📉' },
  Deposit: { active: '💳', inactive: '💳' },
  Referral:{ active: '👥', inactive: '👤' },
  Profile: { active: '👤', inactive: '👤' },
};

function TabIcon({ name, focused }) {
  const icons  = TAB_ICONS[name] || { active: '●', inactive: '○' };
  const labels = { Home: 'Home', Plans: 'Plans', Deposit: 'Deposit', Referral: 'Refer', Profile: 'Profile' };
  return (
    <View style={styles.tabItem}>
      <Text style={[styles.tabIcon, focused && styles.tabIconActive]}>{focused ? icons.active : icons.inactive}</Text>
      <Text style={[styles.tabLabel, focused && styles.tabLabelActive]}>{labels[name]}</Text>
      {focused && <View style={styles.tabDot} />}
    </View>
  );
}

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarStyle:  styles.tabBar,
        tabBarShowLabel: false,
        tabBarIcon: ({ focused }) => <TabIcon name={route.name} focused={focused} />,
      })}
    >
      <Tab.Screen name="Home"    component={HomeScreen}    />
      <Tab.Screen name="Plans"   component={PlansScreen}   />
      <Tab.Screen name="Deposit" component={DepositScreen} />
      <Tab.Screen name="Referral"component={ReferralScreen}/>
      <Tab.Screen name="Profile" component={ProfileScreen} />
    </Tab.Navigator>
  );
}

function AuthStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Login"    component={LoginScreen}    />
      <Stack.Screen name="Register" component={RegisterScreen} />
    </Stack.Navigator>
  );
}

export default function AppNavigator() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Splash"        component={SplashScreen} />
        <Stack.Screen name="Auth"          component={AuthStack}    />
        <Stack.Screen name="Main"          component={MainTabs}     />
        <Stack.Screen name="Transactions"  component={TransactionsScreen}  options={{ presentation: 'modal' }} />
        <Stack.Screen name="Withdraw"      component={WithdrawScreen}      options={{ presentation: 'modal' }} />
        <Stack.Screen name="Notifications" component={ProfileScreen}       />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  tabBar: {
    backgroundColor:  Colors.backgroundCard,
    borderTopColor:   Colors.border,
    borderTopWidth:   1,
    height:           Platform.OS === 'ios' ? 85 : 65,
    paddingBottom:    Platform.OS === 'ios' ? 24 : 8,
    paddingTop:       8,
    elevation:        20,
    shadowColor:      '#D4AF37',
    shadowOpacity:    0.2,
    shadowRadius:     16,
  },
  tabItem: { alignItems: 'center', justifyContent: 'center', gap: 2 },
  tabIcon: { fontSize: 22, opacity: 0.4 },
  tabIconActive: { opacity: 1 },
  tabLabel: { fontFamily: Typography.caption, fontSize: 10, color: Colors.textMuted, opacity: 0.6 },
  tabLabelActive: { color: Colors.gold, opacity: 1 },
  tabDot:  { width: 4, height: 4, borderRadius: 2, backgroundColor: Colors.gold, marginTop: 2 },
});
