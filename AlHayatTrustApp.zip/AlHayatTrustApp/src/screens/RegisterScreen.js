// src/screens/RegisterScreen.js
import React, { useState } from 'react';
import {
  View, Text, ScrollView, StyleSheet,
  TouchableOpacity, StatusBar, KeyboardAvoidingView, Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from '../context/AuthContext';
import { api, MOCK_DASHBOARD } from '../utils/api';
import { GoldButton, InputField, GoldDivider } from '../components/UI';
import { Colors, Typography, Spacing, Radius } from '../utils/theme';

export default function RegisterScreen({ navigation, route }) {
  const { login } = useAuth();
  const refCode   = route.params?.ref || '';

  const [form, setForm] = useState({
    full_name: '', username: '', phone: '',
    email: '', password: '', confirm_password: '',
    referral_code: refCode,
  });
  const [errors, setErrors]   = useState({});
  const [loading, setLoading] = useState(false);
  const [step, setStep]       = useState(1); // 2-step form

  const set = (key, val) => setForm(f => ({ ...f, [key]: val }));

  const validateStep1 = () => {
    const e = {};
    if (!form.full_name.trim()) e.full_name = 'Full name is required';
    if (!form.username.trim())  e.username  = 'Username is required';
    if (form.username.length < 4) e.username = 'Min 4 characters';
    if (!form.phone.trim())     e.phone     = 'Phone number is required';
    if (!/^03\d{9}$/.test(form.phone)) e.phone = 'Enter valid Pakistani number (03xxxxxxxxx)';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const validateStep2 = () => {
    const e = {};
    if (!form.email.trim())                      e.email    = 'Email is required';
    if (!/\S+@\S+\.\S+/.test(form.email))        e.email    = 'Invalid email address';
    if (!form.password)                           e.password = 'Password is required';
    if (form.password.length < 8)                e.password = 'Minimum 8 characters';
    if (form.password !== form.confirm_password) e.confirm_password = 'Passwords do not match';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleNext = () => {
    if (validateStep1()) setStep(2);
  };

  const handleRegister = async () => {
    if (!validateStep2()) return;
    setLoading(true);
    try {
      let userData, token;
      try {
        const res = await api.register(form);
        userData  = res.user;
        token     = res.token;
      } catch {
        userData = { ...MOCK_DASHBOARD.user, name: form.full_name, username: form.username, phone: form.phone, email: form.email };
        token    = 'demo_token_' + Date.now();
      }
      await login(userData, token);
      navigation.replace('Main');
    } catch (err) {
      setErrors({ general: err.message || 'Registration failed.' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <StatusBar barStyle="light-content" backgroundColor={Colors.backgroundDeep} />
      <LinearGradient colors={[Colors.backgroundDeep, '#0d0d1a', Colors.backgroundDeep]} style={StyleSheet.absoluteFillObject} />

      <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
        <View style={styles.container}>

          {/* Header */}
          <View style={styles.header}>
            <TouchableOpacity onPress={() => step === 2 ? setStep(1) : navigation.goBack()} style={styles.back}>
              <Text style={styles.backIcon}>←</Text>
            </TouchableOpacity>
            <View>
              <Text style={styles.title}>Create Account</Text>
              <Text style={styles.subtitle}>Step {step} of 2</Text>
            </View>
          </View>

          {/* Progress bar */}
          <View style={styles.progressBg}>
            <LinearGradient
              colors={['#F0CB5A', '#D4AF37']}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
              style={[styles.progressFill, { width: step === 1 ? '50%' : '100%' }]}
            />
          </View>

          {/* Card */}
          <View style={styles.card}>
            {errors.general && (
              <View style={styles.errorBanner}>
                <Text style={styles.errorBannerText}>⚠️  {errors.general}</Text>
              </View>
            )}

            {step === 1 ? (
              <>
                <Text style={styles.stepLabel}>Personal Information</Text>
                <GoldDivider />
                <InputField label="FULL NAME"  value={form.full_name} onChangeText={v => set('full_name', v)} placeholder="Your full name" icon="👤" error={errors.full_name} />
                <InputField label="USERNAME"   value={form.username}  onChangeText={v => set('username', v)}  placeholder="Choose a username" icon="🆔" error={errors.username} />
                <InputField label="PHONE NUMBER" value={form.phone}   onChangeText={v => set('phone', v)}     placeholder="03xxxxxxxxx" icon="📱" keyboardType="phone-pad" error={errors.phone} />
                <GoldButton title="CONTINUE →" onPress={handleNext} />
              </>
            ) : (
              <>
                <Text style={styles.stepLabel}>Account Security</Text>
                <GoldDivider />
                <InputField label="EMAIL ADDRESS" value={form.email}    onChangeText={v => set('email', v)}            placeholder="your@email.com" icon="✉️" keyboardType="email-address" error={errors.email} />
                <InputField label="PASSWORD"      value={form.password} onChangeText={v => set('password', v)}         placeholder="Min 8 characters" icon="🔒" secureTextEntry error={errors.password} />
                <InputField label="CONFIRM PASSWORD" value={form.confirm_password} onChangeText={v => set('confirm_password', v)} placeholder="Repeat password" icon="🔐" secureTextEntry error={errors.confirm_password} />
                <InputField label="REFERRAL CODE (OPTIONAL)" value={form.referral_code} onChangeText={v => set('referral_code', v)} placeholder="Enter referral code" icon="🎁" />
                <GoldButton title="CREATE ACCOUNT" onPress={handleRegister} loading={loading} />
              </>
            )}
          </View>

          {/* Login link */}
          <View style={styles.loginRow}>
            <Text style={styles.loginText}>Already have an account? </Text>
            <TouchableOpacity onPress={() => navigation.navigate('Login')}>
              <Text style={styles.loginLink}>Sign In</Text>
            </TouchableOpacity>
          </View>

        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  scroll:      { flexGrow: 1 },
  container:   { flex: 1, padding: Spacing.lg, paddingTop: 60, paddingBottom: 40 },
  header:      { flexDirection: 'row', alignItems: 'center', marginBottom: 20 },
  back:        { width: 40, height: 40, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  backIcon:    { fontSize: 22, color: Colors.gold },
  title:       { fontFamily: Typography.display, fontSize: 26, color: Colors.textPrimary },
  subtitle:    { fontFamily: Typography.caption, fontSize: 12, color: Colors.textSecondary, marginTop: 2 },
  progressBg:  { height: 4, backgroundColor: 'rgba(255,255,255,0.08)', borderRadius: 2, marginBottom: 24 },
  progressFill:{ height: 4, borderRadius: 2 },
  card: {
    backgroundColor: Colors.backgroundCard, borderRadius: Radius.xl,
    padding: Spacing.lg, borderWidth: 1, borderColor: Colors.border, marginBottom: 24,
  },
  stepLabel: { fontFamily: Typography.heading, fontSize: 13, color: Colors.gold, letterSpacing: 1, marginBottom: 8 },
  errorBanner: {
    backgroundColor: Colors.dangerBg, borderWidth: 1,
    borderColor: Colors.danger, borderRadius: Radius.md,
    padding: 12, marginBottom: 16,
  },
  errorBannerText: { fontFamily: Typography.body, fontSize: 13, color: Colors.danger },
  loginRow:  { flexDirection: 'row', justifyContent: 'center' },
  loginText: { fontFamily: Typography.body, fontSize: 14, color: Colors.textSecondary },
  loginLink: { fontFamily: Typography.bold, fontSize: 14, color: Colors.gold },
});
