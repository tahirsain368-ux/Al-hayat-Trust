// src/screens/DepositScreen.js
import React, { useState } from 'react';
import {
  View, Text, ScrollView, StyleSheet,
  TouchableOpacity, Image, StatusBar, Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { api } from '../utils/api';
import { GoldButton, InputField, Card, GoldDivider } from '../components/UI';
import { Colors, Typography, Spacing, Radius } from '../utils/theme';

const PAYMENT_METHODS = [
  { id: 'jazzcash',    name: 'JazzCash',     icon: '🟠', color: '#E53935', number: '0300-1234567', title: 'JazzCash Account' },
  { id: 'easypaisa',  name: 'EasyPaisa',    icon: '🟢', color: '#2E7D32', number: '0333-7654321', title: 'EasyPaisa Account' },
  { id: 'bank',       name: 'Bank Transfer', icon: '🏛', color: '#1565C0', number: 'PK86HABB0000001234567890', title: 'Bank Account' },
];

export default function DepositScreen({ navigation }) {
  const [method, setMethod]  = useState(null);
  const [amount, setAmount]  = useState('');
  const [txId, setTxId]      = useState('');
  const [loading, setLoading]= useState(false);

  const handleSubmit = async () => {
    if (!method)  { Alert.alert('Select Method', 'Please choose a payment method.'); return; }
    if (!amount || parseFloat(amount) < 500) { Alert.alert('Invalid', 'Minimum deposit is PKR 500.'); return; }
    if (!txId.trim()) { Alert.alert('Required', 'Please enter your transaction ID.'); return; }

    setLoading(true);
    try {
      await api.createDeposit({ method: method.id, amount: parseFloat(amount), transaction_id: txId });
      Alert.alert('Submitted! ✅', 'Your deposit request is under review. It will be approved within 1-2 hours.', [
        { text: 'OK', onPress: () => navigation.goBack() },
      ]);
    } catch {
      Alert.alert('Submitted! ✅', 'Demo mode: Deposit request recorded. Connect backend to process.', [
        { text: 'OK', onPress: () => navigation.goBack() },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" />

      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.back}>
          <Text style={styles.backIcon}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Add Funds</Text>
      </View>

      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>

        {/* Step 1: Choose Method */}
        <Text style={styles.stepTitle}>1. Select Payment Method</Text>
        <View style={styles.methodRow}>
          {PAYMENT_METHODS.map(m => (
            <TouchableOpacity key={m.id} onPress={() => setMethod(m)} activeOpacity={0.8} style={[styles.methodCard, method?.id === m.id && styles.methodSelected, { borderColor: method?.id === m.id ? m.color : Colors.border }]}>
              <Text style={styles.methodIcon}>{m.icon}</Text>
              <Text style={[styles.methodName, method?.id === m.id && { color: m.color }]}>{m.name}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Step 2: Account details */}
        {method && (
          <>
            <GoldDivider />
            <Text style={styles.stepTitle}>2. Send Payment To</Text>
            <Card style={[styles.accountCard, { borderColor: method.color + '44' }]}>
              <View style={styles.accountRow}>
                <Text style={styles.accountIcon}>{method.icon}</Text>
                <View style={{ flex: 1 }}>
                  <Text style={styles.accountLabel}>{method.title}</Text>
                  <Text style={[styles.accountNumber, { color: method.color }]}>{method.number}</Text>
                  <Text style={styles.accountName}>Al-Hayat Trust</Text>
                </View>
              </View>
              <View style={styles.accountNote}>
                <Text style={styles.noteText}>⚠️ Send exact amount and save your Transaction ID</Text>
              </View>
            </Card>

            <GoldDivider />
            <Text style={styles.stepTitle}>3. Enter Details</Text>

            <InputField
              label="DEPOSIT AMOUNT (PKR)"
              value={amount}
              onChangeText={setAmount}
              placeholder="Minimum PKR 500"
              keyboardType="numeric"
              icon="💰"
            />

            <InputField
              label="TRANSACTION ID"
              value={txId}
              onChangeText={setTxId}
              placeholder="Your payment transaction ID"
              icon="🧾"
            />

            {/* Proof upload note */}
            <Card style={styles.proofNote}>
              <Text style={styles.proofTitle}>📸 Screenshot Proof</Text>
              <Text style={styles.proofText}>After submitting, our team may ask you to share a payment screenshot via WhatsApp for verification.</Text>
              <TouchableOpacity style={styles.whatsappBtn}>
                <Text style={styles.whatsappText}>💬 Contact on WhatsApp: 0300-1234567</Text>
              </TouchableOpacity>
            </Card>

            <GoldButton title="SUBMIT DEPOSIT REQUEST" onPress={handleSubmit} loading={loading} />
          </>
        )}

        {/* Info box */}
        <Card style={styles.infoBox}>
          <Text style={styles.infoTitle}>ℹ️ Deposit Info</Text>
          <Text style={styles.infoText}>• Minimum deposit: PKR 500{'\n'}• Processing time: 1–2 hours{'\n'}• Available 24/7{'\n'}• Keep your transaction ID safe</Text>
        </Card>

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root:   { flex: 1, backgroundColor: Colors.backgroundDeep },
  header: { flexDirection: 'row', alignItems: 'center', paddingTop: 55, paddingHorizontal: Spacing.lg, paddingBottom: 12 },
  back:   { width: 40, height: 40, borderRadius: 20, backgroundColor: Colors.goldSubtle, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  backIcon: { fontSize: 20, color: Colors.gold },
  headerTitle: { fontFamily: Typography.display, fontSize: 24, color: Colors.textPrimary },

  scroll:    { padding: Spacing.lg, paddingBottom: 60 },
  stepTitle: { fontFamily: Typography.heading, fontSize: 13, color: Colors.gold, letterSpacing: 1, marginBottom: 14, marginTop: 4 },

  methodRow:     { flexDirection: 'row', gap: 10, marginBottom: 8 },
  methodCard:    { flex: 1, alignItems: 'center', padding: 14, borderRadius: Radius.lg, borderWidth: 1.5, backgroundColor: Colors.backgroundCard },
  methodSelected:{ backgroundColor: 'rgba(212,175,55,0.08)' },
  methodIcon:    { fontSize: 28, marginBottom: 6 },
  methodName:    { fontFamily: Typography.heading, fontSize: 12, color: Colors.textSecondary, textAlign: 'center' },

  accountCard:  { marginBottom: 8, borderWidth: 1.5 },
  accountRow:   { flexDirection: 'row', alignItems: 'center', gap: 14 },
  accountIcon:  { fontSize: 36 },
  accountLabel: { fontFamily: Typography.caption, fontSize: 11, color: Colors.textMuted, marginBottom: 4 },
  accountNumber:{ fontFamily: Typography.bold, fontSize: 16, marginBottom: 2 },
  accountName:  { fontFamily: Typography.body, fontSize: 13, color: Colors.textSecondary },
  accountNote:  { marginTop: 12, paddingTop: 12, borderTopWidth: 1, borderColor: Colors.border },
  noteText:     { fontFamily: Typography.body, fontSize: 12, color: Colors.warning },

  proofNote:    { marginBottom: Spacing.md, backgroundColor: 'rgba(52,152,219,0.08)', borderColor: Colors.infoBg },
  proofTitle:   { fontFamily: Typography.heading, fontSize: 14, color: Colors.info, marginBottom: 8 },
  proofText:    { fontFamily: Typography.body, fontSize: 13, color: Colors.textSecondary, lineHeight: 20, marginBottom: 10 },
  whatsappBtn:  { backgroundColor: 'rgba(37,211,102,0.15)', borderRadius: Radius.md, padding: 10, alignItems: 'center' },
  whatsappText: { fontFamily: Typography.heading, fontSize: 12, color: '#25D366' },

  infoBox:   { marginTop: Spacing.md },
  infoTitle: { fontFamily: Typography.heading, fontSize: 14, color: Colors.gold, marginBottom: 10 },
  infoText:  { fontFamily: Typography.body, fontSize: 13, color: Colors.textSecondary, lineHeight: 22 },
});
