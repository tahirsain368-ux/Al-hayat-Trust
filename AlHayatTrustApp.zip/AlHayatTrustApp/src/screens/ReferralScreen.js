// src/screens/ReferralScreen.js
import React, { useState } from 'react';
import {
  View, Text, ScrollView, StyleSheet,
  TouchableOpacity, StatusBar, Share, Alert,
} from 'react-native';
import * as Clipboard from 'expo-clipboard';
import { useAuth } from '../context/AuthContext';
import { MOCK_DASHBOARD } from '../utils/api';
import { Card, GoldButton, GoldDivider, Badge } from '../components/UI';
import { Colors, Typography, Spacing, Radius, Shadow } from '../utils/theme';
import { LinearGradient } from 'expo-linear-gradient';

const COMMISSION_LEVELS = [
  { level: 1, label: 'Direct Referrals',    rate: '5%',  icon: '👤', color: Colors.gold },
  { level: 2, label: 'Level 2 Referrals',   rate: '2%',  icon: '👥', color: Colors.info },
  { level: 3, label: 'Level 3 Referrals',   rate: '1%',  icon: '👨‍👩‍👦', color: Colors.success },
];

export default function ReferralScreen({ navigation }) {
  const { user } = useAuth();
  const [copied, setCopied] = useState(false);

  const refCode = user?.referral_code || MOCK_DASHBOARD.user.referral_code;
  const refLink = `https://www.alhayattrust.digital/register?ref=${refCode}`;

  const copyCode = async () => {
    await Clipboard.setStringAsync(refCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const copyLink = async () => {
    await Clipboard.setStringAsync(refLink);
    Alert.alert('Copied!', 'Referral link copied to clipboard.');
  };

  const shareRef = async () => {
    await Share.share({
      message: `Join Al-Hayat Trust — Pakistan's #1 trusted investment platform!\n\nUse my referral code: ${refCode}\n\nRegister here: ${refLink}\n\nEarn daily profits with FBR & SECP verified plans! 💰`,
      title: 'Join Al-Hayat Trust',
    });
  };

  const mockRefs = [
    { id: 1, name: 'Ali Hassan',     phone: '030****567', date: '2026-06-01', invested: 10000, commission: 500 },
    { id: 2, name: 'Sara Malik',     phone: '033****890', date: '2026-05-28', invested: 5000,  commission: 250 },
    { id: 3, name: 'Umar Farooq',   phone: '031****234', date: '2026-05-20', invested: 20000, commission: 1000 },
  ];

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" />

      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.back}>
          <Text style={styles.backIcon}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Referral Program</Text>
      </View>

      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>

        {/* Hero */}
        <LinearGradient colors={['rgba(212,175,55,0.15)', 'transparent']} style={styles.hero}>
          <Text style={styles.heroEmoji}>🤝</Text>
          <Text style={styles.heroTitle}>Invite & Earn</Text>
          <Text style={styles.heroSub}>Earn commission on every investment your referrals make — up to 3 levels deep!</Text>
        </LinearGradient>

        {/* Referral Code Card */}
        <Card style={styles.codeCard} glow>
          <Text style={styles.codeLabel}>YOUR REFERRAL CODE</Text>
          <View style={styles.codeRow}>
            <Text style={styles.codeValue}>{refCode}</Text>
            <TouchableOpacity onPress={copyCode} style={[styles.copyBtn, copied && styles.copiedBtn]}>
              <Text style={[styles.copyBtnText, copied && { color: Colors.success }]}>
                {copied ? '✓ Copied!' : '📋 Copy'}
              </Text>
            </TouchableOpacity>
          </View>
        </Card>

        {/* Share actions */}
        <View style={styles.shareRow}>
          <GoldButton title="🔗 Copy Link" onPress={copyLink} outline small style={{ flex: 1 }} />
          <GoldButton title="📤 Share Now" onPress={shareRef} small style={{ flex: 1 }} />
        </View>

        <GoldDivider />

        {/* Commission structure */}
        <Text style={styles.sectionTitle}>Commission Structure</Text>
        {COMMISSION_LEVELS.map(l => (
          <Card key={l.level} style={styles.levelCard}>
            <View style={styles.levelRow}>
              <View style={[styles.levelBadge, { backgroundColor: `${l.color}22` }]}>
                <Text style={styles.levelIcon}>{l.icon}</Text>
                <Text style={[styles.levelNum, { color: l.color }]}>L{l.level}</Text>
              </View>
              <View style={{ flex: 1, marginLeft: 14 }}>
                <Text style={styles.levelLabel}>{l.label}</Text>
                <Text style={styles.levelDesc}>Earn {l.rate} of their investments</Text>
              </View>
              <View style={[styles.levelRate, { backgroundColor: `${l.color}22`, borderColor: l.color }]}>
                <Text style={[styles.levelRateText, { color: l.color }]}>{l.rate}</Text>
              </View>
            </View>
          </Card>
        ))}

        <GoldDivider />

        {/* Stats */}
        <Text style={styles.sectionTitle}>Your Referral Stats</Text>
        <View style={styles.statsRow}>
          <Card style={styles.statCard}>
            <Text style={styles.statVal}>{mockRefs.length}</Text>
            <Text style={styles.statLabel}>Total Refs</Text>
          </Card>
          <Card style={styles.statCard}>
            <Text style={[styles.statVal, { color: Colors.success }]}>PKR 1,750</Text>
            <Text style={styles.statLabel}>Total Earned</Text>
          </Card>
          <Card style={styles.statCard}>
            <Text style={[styles.statVal, { color: Colors.info }]}>PKR 1,200</Text>
            <Text style={styles.statLabel}>This Month</Text>
          </Card>
        </View>

        {/* Referral list */}
        <Text style={styles.sectionTitle}>My Referrals</Text>
        {mockRefs.map(ref => (
          <Card key={ref.id} style={styles.refCard}>
            <View style={styles.refRow}>
              <View style={styles.refAvatar}>
                <Text style={styles.refInitial}>{ref.name[0]}</Text>
              </View>
              <View style={{ flex: 1, marginLeft: 12 }}>
                <Text style={styles.refName}>{ref.name}</Text>
                <Text style={styles.refPhone}>{ref.phone} · {ref.date}</Text>
                <Text style={styles.refInvested}>Invested: PKR {ref.invested.toLocaleString()}</Text>
              </View>
              <View style={{ alignItems: 'flex-end' }}>
                <Text style={[styles.refCommission]}>+PKR {ref.commission.toLocaleString()}</Text>
                <Badge text="Active" type="success" />
              </View>
            </View>
          </Card>
        ))}

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root:   { flex: 1, backgroundColor: Colors.backgroundDeep },
  header: { flexDirection: 'row', alignItems: 'center', paddingTop: 55, paddingHorizontal: Spacing.lg, paddingBottom: 12 },
  back:   { width: 40, height: 40, borderRadius: 20, backgroundColor: Colors.goldSubtle, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  backIcon: { fontSize: 20, color: Colors.gold },
  headerTitle: { fontFamily: Typography.display, fontSize: 24, color: Colors.textPrimary },
  scroll: { padding: Spacing.lg, paddingBottom: 60 },

  hero:      { alignItems: 'center', padding: Spacing.lg, borderRadius: Radius.xl, marginBottom: 16 },
  heroEmoji: { fontSize: 52, marginBottom: 10 },
  heroTitle: { fontFamily: Typography.display, fontSize: 30, color: Colors.gold, marginBottom: 8 },
  heroSub:   { fontFamily: Typography.body, fontSize: 14, color: Colors.textSecondary, textAlign: 'center', lineHeight: 22 },

  codeCard:  { marginBottom: 14 },
  codeLabel: { fontFamily: Typography.heading, fontSize: 11, color: Colors.textMuted, letterSpacing: 2, marginBottom: 10 },
  codeRow:   { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  codeValue: { fontFamily: Typography.bold, fontSize: 28, color: Colors.gold, letterSpacing: 4 },
  copyBtn:   { backgroundColor: Colors.goldSubtle, paddingHorizontal: 16, paddingVertical: 10, borderRadius: Radius.md, borderWidth: 1, borderColor: Colors.goldBorder },
  copiedBtn: { borderColor: Colors.success, backgroundColor: Colors.successBg },
  copyBtnText: { fontFamily: Typography.heading, fontSize: 13, color: Colors.gold },

  shareRow:  { flexDirection: 'row', gap: 12, marginBottom: 8 },

  sectionTitle: { fontFamily: Typography.display, fontSize: 22, color: Colors.textPrimary, marginBottom: 12 },

  levelCard: { marginBottom: 10 },
  levelRow:  { flexDirection: 'row', alignItems: 'center' },
  levelBadge:{ width: 52, height: 52, borderRadius: 26, alignItems: 'center', justifyContent: 'center' },
  levelIcon: { fontSize: 18 },
  levelNum:  { fontFamily: Typography.bold, fontSize: 12 },
  levelLabel:{ fontFamily: Typography.heading, fontSize: 14, color: Colors.textPrimary, marginBottom: 3 },
  levelDesc: { fontFamily: Typography.caption, fontSize: 12, color: Colors.textSecondary },
  levelRate: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: Radius.md, borderWidth: 1 },
  levelRateText: { fontFamily: Typography.bold, fontSize: 16 },

  statsRow:  { flexDirection: 'row', gap: 10, marginBottom: 16 },
  statCard:  { flex: 1, alignItems: 'center' },
  statVal:   { fontFamily: Typography.display, fontSize: 18, color: Colors.gold, marginBottom: 4 },
  statLabel: { fontFamily: Typography.caption, fontSize: 10, color: Colors.textMuted, textAlign: 'center' },

  refCard:   { marginBottom: 10 },
  refRow:    { flexDirection: 'row', alignItems: 'center' },
  refAvatar: { width: 44, height: 44, borderRadius: 22, backgroundColor: Colors.goldSubtle, borderWidth: 1, borderColor: Colors.goldBorder, alignItems: 'center', justifyContent: 'center' },
  refInitial:{ fontFamily: Typography.bold, fontSize: 18, color: Colors.gold },
  refName:   { fontFamily: Typography.heading, fontSize: 14, color: Colors.textPrimary, marginBottom: 2 },
  refPhone:  { fontFamily: Typography.caption, fontSize: 11, color: Colors.textMuted, marginBottom: 2 },
  refInvested: { fontFamily: Typography.body, fontSize: 12, color: Colors.textSecondary },
  refCommission: { fontFamily: Typography.bold, fontSize: 14, color: Colors.success, marginBottom: 4 },
});
