// src/screens/ProfileScreen.js
import React, { useState } from 'react';
import {
  View, Text, ScrollView, StyleSheet,
  TouchableOpacity, StatusBar, Alert, Switch,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from '../context/AuthContext';
import { MOCK_DASHBOARD } from '../utils/api';
import { Card, GoldDivider, Badge } from '../components/UI';
import { Colors, Typography, Spacing, Radius } from '../utils/theme';

export default function ProfileScreen({ navigation }) {
  const { user, logout } = useAuth();
  const [notifs, setNotifs]   = useState(true);
  const [biometric, setBiometric] = useState(false);

  const u = user || MOCK_DASHBOARD.user;

  const handleLogout = () => {
    Alert.alert('Sign Out', 'Are you sure you want to sign out?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Sign Out', style: 'destructive', onPress: async () => { await logout(); navigation.replace('Auth'); } },
    ]);
  };

  const MenuItem = ({ icon, label, onPress, value, toggle, danger }) => (
    <TouchableOpacity onPress={onPress} activeOpacity={toggle ? 1 : 0.7} style={styles.menuItem}>
      <View style={[styles.menuIcon, danger && styles.menuIconDanger]}>
        <Text style={styles.menuIconText}>{icon}</Text>
      </View>
      <Text style={[styles.menuLabel, danger && { color: Colors.danger }]}>{label}</Text>
      {toggle
        ? <Switch value={value} onValueChange={onPress} trackColor={{ false: '#333', true: Colors.goldDim }} thumbColor={value ? Colors.gold : '#888'} />
        : <Text style={[styles.menuArrow, danger && { color: Colors.danger }]}>›</Text>
      }
    </TouchableOpacity>
  );

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" />

      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>

        {/* Profile Hero */}
        <LinearGradient colors={['rgba(212,175,55,0.15)', 'transparent']} style={styles.hero}>
          <View style={styles.avatarWrap}>
            <LinearGradient colors={['#F0CB5A','#D4AF37','#A88A20']} style={styles.avatar}>
              <Text style={styles.avatarText}>{u.name?.[0] || 'A'}</Text>
            </LinearGradient>
            <View style={styles.avatarBadge}>
              <Text style={styles.avatarBadgeText}>✓</Text>
            </View>
          </View>
          <Text style={styles.userName}>{u.name}</Text>
          <Text style={styles.userHandle}>@{u.username}</Text>
          <View style={styles.rankRow}>
            <Badge text={u.rank || 'Starter'} type="gold" />
          </View>
        </LinearGradient>

        <View style={styles.content}>

          {/* Stats */}
          <View style={styles.statsRow}>
            <View style={styles.statItem}>
              <Text style={styles.statVal}>PKR {MOCK_DASHBOARD.balance.total_invested.toLocaleString()}</Text>
              <Text style={styles.statLabel}>Total Invested</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <Text style={[styles.statVal, { color: Colors.success }]}>PKR {MOCK_DASHBOARD.balance.profit.toLocaleString()}</Text>
              <Text style={styles.statLabel}>Total Profit</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <Text style={styles.statVal}>{MOCK_DASHBOARD.stats.total_referrals}</Text>
              <Text style={styles.statLabel}>Referrals</Text>
            </View>
          </View>

          <GoldDivider />

          {/* Account Info */}
          <Text style={styles.section}>Account Information</Text>
          <Card style={styles.infoCard}>
            {[
              { label: 'Full Name', value: u.name },
              { label: 'Username', value: `@${u.username}` },
              { label: 'Phone', value: u.phone },
              { label: 'Email', value: u.email },
              { label: 'Referral Code', value: u.referral_code },
            ].map((row, i) => (
              <View key={i} style={[styles.infoRow, i < 4 && styles.infoRowBorder]}>
                <Text style={styles.infoLabel}>{row.label}</Text>
                <Text style={styles.infoValue}>{row.value}</Text>
              </View>
            ))}
          </Card>

          <GoldDivider />

          {/* Settings */}
          <Text style={styles.section}>Settings</Text>
          <Card style={styles.menuCard}>
            <MenuItem icon="🔔" label="Push Notifications"  toggle value={notifs}    onPress={() => setNotifs(v => !v)} />
            <View style={styles.menuDivider} />
            <MenuItem icon="👆" label="Biometric Login"     toggle value={biometric} onPress={() => setBiometric(v => !v)} />
            <View style={styles.menuDivider} />
            <MenuItem icon="🔒" label="Change Password"     onPress={() => {}} />
            <View style={styles.menuDivider} />
            <MenuItem icon="📄" label="Terms & Conditions"  onPress={() => {}} />
            <View style={styles.menuDivider} />
            <MenuItem icon="🔏" label="Privacy Policy"      onPress={() => {}} />
            <View style={styles.menuDivider} />
            <MenuItem icon="💬" label="Contact Support"     onPress={() => {}} />
          </Card>

          <GoldDivider />

          {/* Compliance */}
          <Card style={styles.complianceCard}>
            <Text style={styles.complianceTitle}>Regulatory Compliance</Text>
            <View style={styles.complianceRow}>
              <View style={styles.complianceBadge}>
                <Text style={styles.complianceIcon}>🏛</Text>
                <Text style={styles.complianceLabel}>FBR Registered</Text>
              </View>
              <View style={styles.complianceBadge}>
                <Text style={styles.complianceIcon}>⚖️</Text>
                <Text style={styles.complianceLabel}>SECP Compliant</Text>
              </View>
              <View style={styles.complianceBadge}>
                <Text style={styles.complianceIcon}>🔒</Text>
                <Text style={styles.complianceLabel}>SSL Secured</Text>
              </View>
            </View>
          </Card>

          {/* Logout */}
          <Card style={styles.menuCard}>
            <MenuItem icon="🚪" label="Sign Out" onPress={handleLogout} danger />
          </Card>

          <Text style={styles.versionText}>Al-Hayat Trust v1.0.0 · Made in Pakistan 🇵🇰</Text>

        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root:   { flex: 1, backgroundColor: Colors.backgroundDeep },
  scroll: { paddingBottom: 100 },

  hero:    { alignItems: 'center', paddingTop: 70, paddingBottom: 24, paddingHorizontal: Spacing.lg },
  avatarWrap: { position: 'relative', marginBottom: 14 },
  avatar:  { width: 90, height: 90, borderRadius: 45, alignItems: 'center', justifyContent: 'center', shadowColor: '#D4AF37', shadowOpacity: 0.5, shadowRadius: 16, elevation: 12 },
  avatarText: { fontFamily: Typography.display, fontSize: 40, color: '#000' },
  avatarBadge: { position: 'absolute', bottom: 0, right: 0, width: 26, height: 26, borderRadius: 13, backgroundColor: Colors.success, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: Colors.backgroundDeep },
  avatarBadgeText: { fontSize: 12, color: '#fff' },
  userName: { fontFamily: Typography.display, fontSize: 26, color: Colors.textPrimary, marginBottom: 4 },
  userHandle: { fontFamily: Typography.caption, fontSize: 14, color: Colors.textSecondary, marginBottom: 10 },
  rankRow:  { flexDirection: 'row' },

  content:  { padding: Spacing.lg },

  statsRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: Colors.backgroundCard, borderRadius: Radius.lg, borderWidth: 1, borderColor: Colors.border, padding: Spacing.md, marginBottom: 8 },
  statItem: { flex: 1, alignItems: 'center' },
  statVal:  { fontFamily: Typography.display, fontSize: 16, color: Colors.gold, marginBottom: 4 },
  statLabel:{ fontFamily: Typography.caption, fontSize: 10, color: Colors.textMuted },
  statDivider: { width: 1, height: 36, backgroundColor: Colors.border },

  section:  { fontFamily: Typography.display, fontSize: 20, color: Colors.textPrimary, marginBottom: 12 },

  infoCard:  { marginBottom: 8, padding: 0, overflow: 'hidden' },
  infoRow:   { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: Spacing.md, paddingVertical: 14 },
  infoRowBorder: { borderBottomWidth: 1, borderColor: Colors.border },
  infoLabel: { fontFamily: Typography.caption, fontSize: 12, color: Colors.textMuted },
  infoValue: { fontFamily: Typography.heading, fontSize: 13, color: Colors.textPrimary },

  menuCard:  { marginBottom: 8, padding: 0, overflow: 'hidden' },
  menuItem:  { flexDirection: 'row', alignItems: 'center', paddingHorizontal: Spacing.md, paddingVertical: 16 },
  menuIcon:  { width: 38, height: 38, borderRadius: 19, backgroundColor: Colors.goldSubtle, alignItems: 'center', justifyContent: 'center', marginRight: 14 },
  menuIconDanger: { backgroundColor: Colors.dangerBg },
  menuIconText: { fontSize: 18 },
  menuLabel: { flex: 1, fontFamily: Typography.body, fontSize: 15, color: Colors.textPrimary },
  menuArrow: { fontSize: 22, color: Colors.textMuted },
  menuDivider: { height: 1, backgroundColor: Colors.border, marginHorizontal: Spacing.md },

  complianceCard: { marginBottom: 8 },
  complianceTitle: { fontFamily: Typography.heading, fontSize: 13, color: Colors.gold, letterSpacing: 1, marginBottom: 14 },
  complianceRow:  { flexDirection: 'row', justifyContent: 'space-around' },
  complianceBadge:{ alignItems: 'center', gap: 6 },
  complianceIcon: { fontSize: 28 },
  complianceLabel:{ fontFamily: Typography.caption, fontSize: 10, color: Colors.textMuted },

  versionText: { fontFamily: Typography.caption, fontSize: 12, color: Colors.textMuted, textAlign: 'center', marginTop: 8 },
});
