// src/screens/WithdrawScreen.js
import React, { useState } from 'react';
import {
  View, Text, ScrollView, StyleSheet,
  TouchableOpacity, StatusBar, Alert,
} from 'react-native';
import { api, MOCK_DASHBOARD } from '../utils/api';
import { GoldButton, InputField, Card, GoldDivider, Badge } from '../components/UI';
import { Colors, Typography, Spacing, Radius } from '../utils/theme';

const METHODS = [
  { id: 'jazzcash',   name: 'JazzCash',      icon: '🟠' },
  { id: 'easypaisa',  name: 'EasyPaisa',     icon: '🟢' },
  { id: 'bank',       name: 'Bank Transfer',  icon: '🏛' },
];

export default function WithdrawScreen({ navigation }) {
  const [method, setMethod]   = useState(null);
  const [amount, setAmount]   = useState('');
  const [account, setAccount] = useState('');
  const [loading, setLoading] = useState(false);
  const balance = MOCK_DASHBOARD.balance.main;

  const handleWithdraw = async () => {
    if (!method)  { Alert.alert('Select Method', 'Choose a withdrawal method.'); return; }
    const a = parseFloat(amount);
    if (!a || a < 1000) { Alert.alert('Invalid', 'Minimum withdrawal is PKR 1,000.'); return; }
    if (a > balance)    { Alert.alert('Insufficient', `Your balance is PKR ${balance.toLocaleString()}.`); return; }
    if (!account.trim()){ Alert.alert('Required', 'Enter your account number.'); return; }
    setLoading(true);
    try {
      await api.createWithdrawal({ method: method.id, amount: a, account_number: account });
      Alert.alert('Request Submitted ✅', 'Your withdrawal will be processed within 24 hours.', [
        { text: 'OK', onPress: () => navigation.goBack() },
      ]);
    } catch {
      Alert.alert('Submitted ✅', 'Demo mode: Withdrawal recorded.', [
        { text: 'OK', onPress: () => navigation.goBack() },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" />

      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.back}>
          <Text style={styles.backIcon}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Withdraw Funds</Text>
      </View>

      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>

        {/* Balance display */}
        <Card style={styles.balanceCard} glow>
          <Text style={styles.balanceLabel}>AVAILABLE BALANCE</Text>
          <Text style={styles.balanceValue}>PKR {balance.toLocaleString()}</Text>
          <Badge text="Available to Withdraw" type="success" />
        </Card>

        <GoldDivider />

        {/* Method */}
        <Text style={styles.stepTitle}>1. Select Withdrawal Method</Text>
        <View style={styles.methodRow}>
          {METHODS.map(m => (
            <TouchableOpacity key={m.id} onPress={() => setMethod(m)} activeOpacity={0.8}
              style={[styles.methodCard, method?.id === m.id && styles.methodSelected]}>
              <Text style={styles.methodIcon}>{m.icon}</Text>
              <Text style={[styles.methodName, method?.id === m.id && { color: Colors.gold }]}>{m.name}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <GoldDivider />

        <Text style={styles.stepTitle}>2. Enter Withdrawal Details</Text>

        <InputField
          label="AMOUNT (PKR)"
          value={amount}
          onChangeText={setAmount}
          placeholder="Minimum PKR 1,000"
          keyboardType="numeric"
          icon="💸"
        />

        <InputField
          label={method?.id === 'bank' ? 'IBAN / ACCOUNT NUMBER' : 'PHONE NUMBER'}
          value={account}
          onChangeText={setAccount}
          placeholder={method?.id === 'bank' ? 'PK....' : '03xxxxxxxxx'}
          keyboardType={method?.id === 'bank' ? 'default' : 'phone-pad'}
          icon="📲"
        />

        {amount && parseFloat(amount) >= 1000 && (
          <Card style={styles.summaryCard}>
            <Text style={styles.summaryTitle}>💰 Summary</Text>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>Requested:</Text>
              <Text style={styles.summaryVal}>PKR {parseFloat(amount).toLocaleString()}</Text>
            </View>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>Service Fee (2%):</Text>
              <Text style={[styles.summaryVal, { color: Colors.danger }]}>- PKR {(parseFloat(amount) * 0.02).toFixed(0)}</Text>
            </View>
            <View style={[styles.summaryRow, styles.summaryTotal]}>
              <Text style={styles.summaryLabel}>You Receive:</Text>
              <Text style={[styles.summaryVal, { color: Colors.success, fontSize: 16 }]}>PKR {(parseFloat(amount) * 0.98).toFixed(0)}</Text>
            </View>
          </Card>
        )}

        <GoldButton title="SUBMIT WITHDRAWAL REQUEST" onPress={handleWithdraw} loading={loading} />

        <Card style={styles.infoBox}>
          <Text style={styles.infoTitle}>ℹ️ Withdrawal Policy</Text>
          <Text style={styles.infoText}>• Minimum: PKR 1,000{'\n'}• Processing: Within 24 hours{'\n'}• Service fee: 2%{'\n'}• Available Monday–Saturday</Text>
        </Card>

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root:   { flex: 1, backgroundColor: Colors.backgroundDeep },
  header: { flexDirection: 'row', alignItems: 'center', paddingTop: 55, paddingHorizontal: Spacing.lg, paddingBottom: 12 },
  back:   { width: 40, height: 40, borderRadius: 20, backgroundColor: Colors.goldSubtle, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  backIcon: { fontSize: 20, color: Colors.gold },
  headerTitle: { fontFamily: Typography.display, fontSize: 24, color: Colors.textPrimary },
  scroll: { padding: Spacing.lg, paddingBottom: 60 },

  balanceCard:  { alignItems: 'center', padding: Spacing.lg, marginBottom: 8 },
  balanceLabel: { fontFamily: Typography.heading, fontSize: 11, color: Colors.textMuted, letterSpacing: 2, marginBottom: 8 },
  balanceValue: { fontFamily: Typography.display, fontSize: 36, color: Colors.gold, marginBottom: 10 },

  stepTitle: { fontFamily: Typography.heading, fontSize: 13, color: Colors.gold, letterSpacing: 1, marginBottom: 14, marginTop: 4 },
  methodRow: { flexDirection: 'row', gap: 10, marginBottom: 8 },
  methodCard: { flex: 1, alignItems: 'center', padding: 14, borderRadius: Radius.lg, borderWidth: 1.5, borderColor: Colors.border, backgroundColor: Colors.backgroundCard },
  methodSelected: { borderColor: Colors.gold, backgroundColor: Colors.goldSubtle },
  methodIcon: { fontSize: 28, marginBottom: 6 },
  methodName: { fontFamily: Typography.heading, fontSize: 11, color: Colors.textSecondary, textAlign: 'center' },

  summaryCard:  { marginBottom: Spacing.md, backgroundColor: Colors.goldSubtle, borderColor: Colors.goldBorder },
  summaryTitle: { fontFamily: Typography.heading, fontSize: 13, color: Colors.gold, marginBottom: 12 },
  summaryRow:   { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  summaryTotal: { borderTopWidth: 1, borderColor: Colors.border, paddingTop: 8, marginTop: 4 },
  summaryLabel: { fontFamily: Typography.body, fontSize: 13, color: Colors.textSecondary },
  summaryVal:   { fontFamily: Typography.bold, fontSize: 14, color: Colors.textPrimary },

  infoBox:   { marginTop: Spacing.md },
  infoTitle: { fontFamily: Typography.heading, fontSize: 14, color: Colors.gold, marginBottom: 10 },
  infoText:  { fontFamily: Typography.body, fontSize: 13, color: Colors.textSecondary, lineHeight: 22 },
});
