// src/screens/HomeScreen.js
import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, ScrollView, StyleSheet, Animated,
  TouchableOpacity, RefreshControl, Dimensions, StatusBar,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { LineChart } from 'react-native-chart-kit';
import { useAuth } from '../context/AuthContext';
import { api, MOCK_DASHBOARD } from '../utils/api';
import { Card, Badge, SectionHeader, GoldDivider, EmptyState } from '../components/UI';
import { Colors, Typography, Spacing, Radius, Shadow } from '../utils/theme';

const { width } = Dimensions.get('window');

export default function HomeScreen({ navigation }) {
  const { user, logout }      = useAuth();
  const [data, setData]       = useState(null);
  const [refreshing, setRefreshing] = useState(false);
  const scrollY = useRef(new Animated.Value(0)).current;

  const fetchData = async () => {
    try {
      const res = await api.getDashboard();
      setData(res);
    } catch {
      setData(MOCK_DASHBOARD);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const onRefresh = async () => {
    setRefreshing(true);
    await fetchData();
    setRefreshing(false);
  };

  const txIcon   = { profit: '📈', deposit: '💳', referral: '👥', withdrawal: '💸' };
  const txBadge  = { completed: 'success', pending: 'warning', rejected: 'danger' };

  const headerBg = scrollY.interpolate({
    inputRange: [0, 100],
    outputRange: ['rgba(10,10,15,0)', 'rgba(10,10,15,1)'],
    extrapolate: 'clamp',
  });

  if (!data) {
    return (
      <View style={styles.loading}>
        <Text style={styles.loadingText}>Loading your portfolio...</Text>
      </View>
    );
  }

  const chartLabels = data.chart_data.map(d => d.date);
  const chartData   = data.chart_data.map(d => d.amount);

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" backgroundColor={Colors.backgroundDeep} />

      {/* Sticky animated header */}
      <Animated.View style={[styles.stickyHeader, { backgroundColor: headerBg }]}>
        <View style={styles.headerContent}>
          <View>
            <Text style={styles.greeting}>Assalam o Alaikum 👋</Text>
            <Text style={styles.userName}>{user?.name || 'Investor'}</Text>
          </View>
          <TouchableOpacity onPress={() => navigation.navigate('Notifications')} style={styles.notifBtn}>
            <Text style={styles.notifIcon}>🔔</Text>
          </TouchableOpacity>
        </View>
      </Animated.View>

      <Animated.ScrollView
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: false })}
        scrollEventThrottle={16}
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={Colors.gold} />}
      >

        {/* Hero Balance Card */}
        <LinearGradient colors={['#1a1500', '#0a0a0f']} style={styles.heroBg}>
          <View style={styles.heroCard}>
            <LinearGradient
              colors={['rgba(212,175,55,0.15)', 'rgba(212,175,55,0.03)', 'transparent']}
              style={styles.heroGradientOverlay}
            />
            <Text style={styles.heroLabel}>TOTAL PORTFOLIO VALUE</Text>
            <Text style={styles.heroBalance}>
              PKR {(data.balance.main + data.balance.profit).toLocaleString()}
            </Text>
            <View style={styles.heroRow}>
              <View style={styles.heroStat}>
                <Text style={styles.heroStatVal}>PKR {data.balance.main.toLocaleString()}</Text>
                <Text style={styles.heroStatLabel}>Main Balance</Text>
              </View>
              <View style={styles.heroDivider} />
              <View style={styles.heroStat}>
                <Text style={[styles.heroStatVal, { color: Colors.success }]}>PKR {data.balance.profit.toLocaleString()}</Text>
                <Text style={styles.heroStatLabel}>Total Profit</Text>
              </View>
              <View style={styles.heroDivider} />
              <View style={styles.heroStat}>
                <Text style={[styles.heroStatVal, { color: Colors.info }]}>PKR {data.balance.referral.toLocaleString()}</Text>
                <Text style={styles.heroStatLabel}>Referral</Text>
              </View>
            </View>

            {/* Action buttons */}
            <View style={styles.heroActions}>
              <TouchableOpacity style={styles.heroAction} onPress={() => navigation.navigate('Deposit')}>
                <LinearGradient colors={['#F0CB5A','#D4AF37','#A88A20']} style={styles.heroActionGrad}>
                  <Text style={styles.heroActionIcon}>💳</Text>
                </LinearGradient>
                <Text style={styles.heroActionText}>Deposit</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.heroAction} onPress={() => navigation.navigate('Withdraw')}>
                <View style={styles.heroActionOutline}>
                  <Text style={styles.heroActionIcon}>💸</Text>
                </View>
                <Text style={styles.heroActionText}>Withdraw</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.heroAction} onPress={() => navigation.navigate('Plans')}>
                <View style={styles.heroActionOutline}>
                  <Text style={styles.heroActionIcon}>📊</Text>
                </View>
                <Text style={styles.heroActionText}>Invest</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.heroAction} onPress={() => navigation.navigate('Referral')}>
                <View style={styles.heroActionOutline}>
                  <Text style={styles.heroActionIcon}>👥</Text>
                </View>
                <Text style={styles.heroActionText}>Refer</Text>
              </TouchableOpacity>
            </View>
          </View>
        </LinearGradient>

        <View style={styles.content}>

          {/* Stats row */}
          <View style={styles.statsRow}>
            {[
              { label: "Today's Profit", value: `PKR ${data.stats.today_profit.toLocaleString()}`, icon: '📈', color: Colors.success },
              { label: 'Active Plans',   value: data.stats.active_plans,   icon: '📋', color: Colors.gold },
              { label: 'Total Refs',     value: data.stats.total_referrals, icon: '👥', color: Colors.info },
              { label: 'Withdrawals',    value: `PKR ${data.balance.withdrawn.toLocaleString()}`, icon: '💸', color: Colors.warning },
            ].map((s, i) => (
              <Card key={i} style={styles.statCard}>
                <Text style={styles.statIcon}>{s.icon}</Text>
                <Text style={[styles.statValue, { color: s.color }]}>{s.value}</Text>
                <Text style={styles.statLabel}>{s.label}</Text>
              </Card>
            ))}
          </View>

          {/* Chart */}
          <Card style={styles.chartCard} glow>
            <SectionHeader title="Growth Chart" action="7 Days" />
            <LineChart
              data={{
                labels: chartLabels,
                datasets: [{ data: chartData }],
              }}
              width={width - Spacing.lg * 2 - Spacing.md * 2}
              height={180}
              chartConfig={{
                backgroundColor: 'transparent',
                backgroundGradientFrom: Colors.backgroundCard,
                backgroundGradientTo: Colors.backgroundCard,
                decimalPlaces: 0,
                color: (opacity = 1) => `rgba(212,175,55,${opacity})`,
                labelColor: () => Colors.textMuted,
                propsForDots: { r: '4', strokeWidth: '2', stroke: Colors.goldLight },
                propsForBackgroundLines: { stroke: 'rgba(255,255,255,0.05)' },
              }}
              bezier
              style={{ borderRadius: Radius.md, marginLeft: -16 }}
              withInnerLines
              withShadow={false}
            />
          </Card>

          {/* Rank card */}
          <Card style={styles.rankCard}>
            <View style={styles.rankRow}>
              <View>
                <Text style={styles.rankLabel}>CURRENT RANK</Text>
                <Text style={styles.rankValue}>{data.user?.rank || 'Starter'}</Text>
              </View>
              <LinearGradient colors={['#F0CB5A','#D4AF37']} style={styles.rankBadge}>
                <Text style={styles.rankBadgeText}>🏆</Text>
              </LinearGradient>
            </View>
            <View style={styles.rankProgressBg}>
              <LinearGradient colors={['#F0CB5A','#D4AF37']} start={{x:0,y:0}} end={{x:1,y:0}} style={[styles.rankProgressFill, { width: '45%' }]} />
            </View>
            <Text style={styles.rankHint}>Invest more to reach Gold rank</Text>
          </Card>

          {/* Recent Transactions */}
          <SectionHeader
            title="Recent Transactions"
            action="View All"
            onAction={() => navigation.navigate('Transactions')}
          />

          {data.recent_transactions.length === 0 ? (
            <EmptyState icon="📭" title="No transactions yet" subtitle="Make your first deposit to get started" />
          ) : (
            data.recent_transactions.map(tx => (
              <Card key={tx.id} style={styles.txCard}>
                <View style={styles.txRow}>
                  <View style={styles.txIconWrap}>
                    <Text style={styles.txIcon}>{txIcon[tx.type] || '💰'}</Text>
                  </View>
                  <View style={styles.txInfo}>
                    <Text style={styles.txDesc}>{tx.desc}</Text>
                    <Text style={styles.txDate}>{tx.date}</Text>
                  </View>
                  <View style={styles.txRight}>
                    <Text style={[styles.txAmount, { color: tx.type === 'withdrawal' ? Colors.danger : Colors.success }]}>
                      {tx.type === 'withdrawal' ? '-' : '+'}PKR {tx.amount.toLocaleString()}
                    </Text>
                    <Badge text={tx.status} type={txBadge[tx.status]} />
                  </View>
                </View>
              </Card>
            ))
          )}

          {/* Trust Footer */}
          <GoldDivider />
          <View style={styles.trustRow}>
            <Text style={styles.trustText}>🏛 FBR Registered</Text>
            <Text style={styles.trustDot}>•</Text>
            <Text style={styles.trustText}>⚖️ SECP Compliant</Text>
            <Text style={styles.trustDot}>•</Text>
            <Text style={styles.trustText}>🔒 SSL Secured</Text>
          </View>

        </View>
      </Animated.ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root:    { flex: 1, backgroundColor: Colors.backgroundDeep },
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: Colors.backgroundDeep },
  loadingText: { fontFamily: Typography.body, color: Colors.textSecondary },

  stickyHeader: { position: 'absolute', top: 0, left: 0, right: 0, zIndex: 100, paddingTop: 50, paddingBottom: 12, paddingHorizontal: Spacing.lg },
  headerContent: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  greeting:  { fontFamily: Typography.caption, fontSize: 12, color: Colors.textMuted },
  userName:  { fontFamily: Typography.display, fontSize: 22, color: Colors.textPrimary },
  notifBtn:  { width: 44, height: 44, borderRadius: 22, backgroundColor: 'rgba(212,175,55,0.1)', alignItems: 'center', justifyContent: 'center' },
  notifIcon: { fontSize: 18 },

  scroll:  { paddingBottom: 100 },

  heroBg:  { paddingTop: 110, paddingBottom: 0 },
  heroCard: {
    marginHorizontal: Spacing.lg, marginBottom: 0,
    backgroundColor: Colors.backgroundCard,
    borderRadius: Radius.xl, padding: Spacing.lg,
    borderWidth: 1, borderColor: Colors.goldBorder, overflow: 'hidden',
    ...Shadow.gold,
  },
  heroGradientOverlay: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 },
  heroLabel:  { fontFamily: Typography.heading, fontSize: 10, color: Colors.textMuted, letterSpacing: 2, marginBottom: 6 },
  heroBalance:{ fontFamily: Typography.display, fontSize: 36, color: Colors.gold, marginBottom: 16 },
  heroRow:    { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 20 },
  heroStat:   { flex: 1, alignItems: 'center' },
  heroStatVal:{ fontFamily: Typography.heading, fontSize: 14, color: Colors.textPrimary },
  heroStatLabel: { fontFamily: Typography.caption, fontSize: 10, color: Colors.textMuted, marginTop: 2 },
  heroDivider: { width: 1, backgroundColor: Colors.border },

  heroActions: { flexDirection: 'row', justifyContent: 'space-around' },
  heroAction:  { alignItems: 'center', gap: 6 },
  heroActionGrad: { width: 48, height: 48, borderRadius: 24, alignItems: 'center', justifyContent: 'center' },
  heroActionOutline: {
    width: 48, height: 48, borderRadius: 24,
    borderWidth: 1.5, borderColor: Colors.goldBorder,
    alignItems: 'center', justifyContent: 'center',
  },
  heroActionIcon: { fontSize: 20 },
  heroActionText: { fontFamily: Typography.caption, fontSize: 11, color: Colors.textSecondary },

  content:   { padding: Spacing.lg },

  statsRow:  { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: Spacing.md },
  statCard:  { width: (width - Spacing.lg * 2 - 10) / 2 - 5, padding: Spacing.sm, alignItems: 'center' },
  statIcon:  { fontSize: 22, marginBottom: 4 },
  statValue: { fontFamily: Typography.display, fontSize: 16, color: Colors.gold },
  statLabel: { fontFamily: Typography.caption, fontSize: 10, color: Colors.textMuted, textAlign: 'center', marginTop: 2 },

  chartCard: { marginBottom: Spacing.md },

  rankCard:  { marginBottom: Spacing.md },
  rankRow:   { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  rankLabel: { fontFamily: Typography.heading, fontSize: 10, color: Colors.textMuted, letterSpacing: 2, marginBottom: 4 },
  rankValue: { fontFamily: Typography.display, fontSize: 24, color: Colors.gold },
  rankBadge: { width: 48, height: 48, borderRadius: 24, alignItems: 'center', justifyContent: 'center' },
  rankBadgeText: { fontSize: 24 },
  rankProgressBg:   { height: 6, backgroundColor: 'rgba(255,255,255,0.08)', borderRadius: 3, marginBottom: 8 },
  rankProgressFill: { height: 6, borderRadius: 3 },
  rankHint:  { fontFamily: Typography.caption, fontSize: 12, color: Colors.textMuted },

  txCard:  { marginBottom: 10 },
  txRow:   { flexDirection: 'row', alignItems: 'center' },
  txIconWrap: { width: 44, height: 44, borderRadius: 22, backgroundColor: Colors.goldSubtle, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  txIcon:    { fontSize: 20 },
  txInfo:    { flex: 1 },
  txDesc:    { fontFamily: Typography.heading, fontSize: 14, color: Colors.textPrimary, marginBottom: 3 },
  txDate:    { fontFamily: Typography.caption, fontSize: 11, color: Colors.textMuted },
  txRight:   { alignItems: 'flex-end', gap: 4 },
  txAmount:  { fontFamily: Typography.bold, fontSize: 14 },

  trustRow:  { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 8, flexWrap: 'wrap' },
  trustText: { fontFamily: Typography.caption, fontSize: 11, color: Colors.textMuted },
  trustDot:  { color: Colors.goldDim },
});
