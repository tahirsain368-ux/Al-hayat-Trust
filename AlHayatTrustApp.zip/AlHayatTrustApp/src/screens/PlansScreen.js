// src/screens/PlansScreen.js
import React, { useState, useEffect } from 'react';
import {
  View, Text, ScrollView, StyleSheet,
  TouchableOpacity, Modal, StatusBar, Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { api, MOCK_PLANS } from '../utils/api';
import { GoldButton, InputField, Card, GoldDivider, Badge } from '../components/UI';
import { Colors, Typography, Spacing, Radius, Shadow } from '../utils/theme';

export default function PlansScreen({ navigation }) {
  const [plans, setPlans]           = useState([]);
  const [selected, setSelected]     = useState(null);
  const [amount, setAmount]         = useState('');
  const [modalVisible, setModal]    = useState(false);
  const [loading, setLoading]       = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const res = await api.getPlans();
        setPlans(res.plans || MOCK_PLANS);
      } catch {
        setPlans(MOCK_PLANS);
      }
    })();
  }, []);

  const openInvest = (plan) => {
    setSelected(plan);
    setAmount('');
    setModal(true);
  };

  const calcReturn = () => {
    const a = parseFloat(amount) || 0;
    return {
      daily:  (a * selected.daily_profit / 100).toFixed(0),
      total:  (a * selected.total_return / 100).toFixed(0),
      profit: (a * selected.total_return / 100).toFixed(0),
    };
  };

  const handleInvest = async () => {
    const a = parseFloat(amount);
    if (!a || a < selected.min) {
      Alert.alert('Invalid Amount', `Minimum investment is PKR ${selected.min.toLocaleString()}`);
      return;
    }
    if (selected.max && a > selected.max) {
      Alert.alert('Invalid Amount', `Maximum investment is PKR ${selected.max.toLocaleString()}`);
      return;
    }
    setLoading(true);
    try {
      await api.invest({ plan_id: selected.id, amount: a });
      Alert.alert('Success! 🎉', 'Your investment has been activated.', [{ text: 'OK', onPress: () => { setModal(false); navigation.navigate('Home'); } }]);
    } catch {
      Alert.alert('Demo Mode', 'Investment recorded in demo. Connect your backend to activate.', [{ text: 'OK', onPress: () => setModal(false) }]);
    } finally {
      setLoading(false);
    }
  };

  const PlanCard = ({ plan }) => (
    <TouchableOpacity activeOpacity={0.85} onPress={() => openInvest(plan)} style={styles.planCardWrap}>
      <LinearGradient
        colors={['rgba(212,175,55,0.12)', 'rgba(212,175,55,0.04)', 'transparent']}
        style={styles.planCard}
      >
        <View style={[styles.planHeader, { borderBottomColor: plan.color }]}>
          <Text style={[styles.planName, { color: plan.color }]}>{plan.name}</Text>
          <View style={[styles.planBadge, { backgroundColor: `${plan.color}22`, borderColor: plan.color }]}>
            <Text style={[styles.planBadgeText, { color: plan.color }]}>{plan.daily_profit}% / day</Text>
          </View>
        </View>

        <View style={styles.planStats}>
          <View style={styles.planStat}>
            <Text style={styles.planStatVal}>PKR {plan.min.toLocaleString()}</Text>
            <Text style={styles.planStatLabel}>Min Invest</Text>
          </View>
          <View style={styles.planStatDivider} />
          <View style={styles.planStat}>
            <Text style={styles.planStatVal}>{plan.duration} Days</Text>
            <Text style={styles.planStatLabel}>Duration</Text>
          </View>
          <View style={styles.planStatDivider} />
          <View style={styles.planStat}>
            <Text style={[styles.planStatVal, { color: Colors.success }]}>{plan.total_return}%</Text>
            <Text style={styles.planStatLabel}>Total Return</Text>
          </View>
        </View>

        <LinearGradient colors={[plan.color, '#A88A20']} start={{x:0,y:0}} end={{x:1,y:0}} style={styles.investBtn}>
          <Text style={styles.investBtnText}>INVEST NOW →</Text>
        </LinearGradient>
      </LinearGradient>
    </TouchableOpacity>
  );

  const ret = selected && amount ? calcReturn() : null;

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" backgroundColor={Colors.backgroundDeep} />

      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.back}>
          <Text style={styles.backIcon}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Investment Plans</Text>
      </View>

      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        <Text style={styles.heroText}>Choose Your{'\n'}Investment Plan</Text>
        <Text style={styles.heroSub}>Grow your wealth with our secure, profit-driven plans</Text>

        <GoldDivider />

        {plans.map(plan => <PlanCard key={plan.id} plan={plan} />)}

        <Card style={styles.infoCard}>
          <Text style={styles.infoTitle}>📋 How It Works</Text>
          <Text style={styles.infoText}>1. Choose a plan matching your budget{'\n'}2. Enter your investment amount{'\n'}3. Profits credited daily to your account{'\n'}4. Withdraw anytime after plan completion</Text>
        </Card>
      </ScrollView>

      {/* Invest Modal */}
      <Modal visible={modalVisible} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>{selected?.name} Plan</Text>
              <TouchableOpacity onPress={() => setModal(false)}>
                <Text style={styles.modalClose}>✕</Text>
              </TouchableOpacity>
            </View>

            <GoldDivider />

            <InputField
              label="INVESTMENT AMOUNT (PKR)"
              value={amount}
              onChangeText={setAmount}
              placeholder={`Min: ${selected?.min?.toLocaleString()}`}
              keyboardType="numeric"
              icon="💰"
            />

            {ret && (
              <Card style={styles.calcCard}>
                <Text style={styles.calcTitle}>📊 Profit Calculator</Text>
                <View style={styles.calcRow}>
                  <Text style={styles.calcLabel}>Daily Profit:</Text>
                  <Text style={styles.calcVal}>PKR {parseInt(ret.daily).toLocaleString()}</Text>
                </View>
                <View style={styles.calcRow}>
                  <Text style={styles.calcLabel}>Total Profit:</Text>
                  <Text style={[styles.calcVal, { color: Colors.success }]}>PKR {parseInt(ret.total).toLocaleString()}</Text>
                </View>
                <View style={styles.calcRow}>
                  <Text style={styles.calcLabel}>After {selected?.duration} Days:</Text>
                  <Text style={[styles.calcVal, { color: Colors.gold }]}>PKR {(parseFloat(amount) + parseInt(ret.total)).toLocaleString()}</Text>
                </View>
              </Card>
            )}

            <GoldButton title="CONFIRM INVESTMENT" onPress={handleInvest} loading={loading} />
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  root:    { flex: 1, backgroundColor: Colors.backgroundDeep },
  header:  { flexDirection: 'row', alignItems: 'center', paddingTop: 55, paddingHorizontal: Spacing.lg, paddingBottom: 12 },
  back:    { width: 40, height: 40, borderRadius: 20, backgroundColor: Colors.goldSubtle, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  backIcon:{ fontSize: 20, color: Colors.gold },
  headerTitle: { fontFamily: Typography.display, fontSize: 24, color: Colors.textPrimary },

  scroll:  { padding: Spacing.lg, paddingBottom: 60 },
  heroText:{ fontFamily: Typography.display, fontSize: 32, color: Colors.textPrimary, marginBottom: 8, lineHeight: 40 },
  heroSub: { fontFamily: Typography.body, fontSize: 14, color: Colors.textSecondary, marginBottom: 16 },

  planCardWrap: { marginBottom: 16, borderRadius: Radius.xl, overflow: 'hidden', borderWidth: 1, borderColor: Colors.goldBorder, ...Shadow.gold },
  planCard:     { padding: Spacing.lg },
  planHeader:   { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingBottom: 16, marginBottom: 16, borderBottomWidth: 1 },
  planName:     { fontFamily: Typography.display, fontSize: 26 },
  planBadge:    { paddingHorizontal: 12, paddingVertical: 6, borderRadius: Radius.full, borderWidth: 1 },
  planBadgeText:{ fontFamily: Typography.bold, fontSize: 13 },

  planStats:    { flexDirection: 'row', justifyContent: 'space-around', marginBottom: 20 },
  planStat:     { alignItems: 'center' },
  planStatVal:  { fontFamily: Typography.heading, fontSize: 16, color: Colors.textPrimary, marginBottom: 4 },
  planStatLabel:{ fontFamily: Typography.caption, fontSize: 11, color: Colors.textMuted },
  planStatDivider: { width: 1, backgroundColor: Colors.border },

  investBtn:  { paddingVertical: 14, borderRadius: Radius.md, alignItems: 'center' },
  investBtnText: { fontFamily: Typography.bold, fontSize: 14, color: '#000', letterSpacing: 1 },

  infoCard:  { marginTop: 8 },
  infoTitle: { fontFamily: Typography.heading, fontSize: 15, color: Colors.gold, marginBottom: 12 },
  infoText:  { fontFamily: Typography.body, fontSize: 13, color: Colors.textSecondary, lineHeight: 22 },

  // Modal
  modalOverlay: { flex: 1, backgroundColor: Colors.overlay, justifyContent: 'flex-end' },
  modalCard:    { backgroundColor: Colors.backgroundCard, borderTopLeftRadius: 28, borderTopRightRadius: 28, padding: Spacing.lg, borderTopWidth: 1, borderColor: Colors.goldBorder },
  modalHeader:  { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  modalTitle:   { fontFamily: Typography.display, fontSize: 24, color: Colors.textPrimary },
  modalClose:   { fontSize: 20, color: Colors.textSecondary, padding: 4 },
  calcCard:     { marginBottom: 20, backgroundColor: Colors.goldSubtle },
  calcTitle:    { fontFamily: Typography.heading, fontSize: 13, color: Colors.gold, marginBottom: 10 },
  calcRow:      { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  calcLabel:    { fontFamily: Typography.body, fontSize: 13, color: Colors.textSecondary },
  calcVal:      { fontFamily: Typography.bold, fontSize: 13, color: Colors.textPrimary },
});
