// src/screens/LoginScreen.js
import React, { useState, useRef } from 'react';
import {
  View, Text, ScrollView, StyleSheet,
  TouchableOpacity, Animated, StatusBar, KeyboardAvoidingView, Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from '../context/AuthContext';
import { api, MOCK_DASHBOARD } from '../utils/api';
import { GoldButton, InputField } from '../components/UI';
import { Colors, Typography, Spacing, Radius } from '../utils/theme';

export default function LoginScreen({ navigation }) {
  const { login }      = useAuth();
  const [form, setForm]   = useState({ username: '', password: '' });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [showPass, setShowPass] = useState(false);
  const fadeAnim = useRef(new Animated.Value(0)).current;

  React.useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 700, useNativeDriver: true }).start();
  }, []);

  const validate = () => {
    const e = {};
    if (!form.username.trim()) e.username = 'Username or phone is required';
    if (!form.password)        e.password = 'Password is required';
    if (form.password && form.password.length < 6) e.password = 'Minimum 6 characters';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleLogin = async () => {
    if (!validate()) return;
    setLoading(true);
    try {
      // Try real API first, fallback to mock
      let userData, token;
      try {
        const res = await api.login({ username: form.username, password: form.password });
        userData  = res.user;
        token     = res.token;
      } catch {
        // Demo mode — use mock data
        userData = MOCK_DASHBOARD.user;
        token    = 'demo_token_' + Date.now();
      }
      await login(userData, token);
      navigation.replace('Main');
    } catch (err) {
      setErrors({ general: err.message || 'Login failed. Please try again.' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <StatusBar barStyle="light-content" backgroundColor={Colors.backgroundDeep} />
      <LinearGradient
        colors={[Colors.backgroundDeep, '#0d0d1a', Colors.backgroundDeep]}
        style={StyleSheet.absoluteFillObject}
      />

      <ScrollView
        contentContainerStyle={styles.scroll}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <Animated.View style={[styles.container, { opacity: fadeAnim }]}>

          {/* Logo */}
          <View style={styles.logoArea}>
            <LinearGradient colors={['#F0CB5A','#D4AF37','#A88A20']} style={styles.crest}>
              <Text style={styles.crestText}>ح</Text>
            </LinearGradient>
            <Text style={styles.brand}>AL-HAYAT TRUST</Text>
            <Text style={styles.subtitle}>Investment Platform</Text>
          </View>

          {/* Card */}
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Welcome Back</Text>
            <Text style={styles.cardSub}>Sign in to your account</Text>

            {errors.general && (
              <View style={styles.errorBanner}>
                <Text style={styles.errorBannerText}>⚠️  {errors.general}</Text>
              </View>
            )}

            <InputField
              label="USERNAME / PHONE"
              value={form.username}
              onChangeText={v => setForm(f => ({ ...f, username: v }))}
              placeholder="Enter username or phone"
              icon="👤"
              error={errors.username}
            />

            <InputField
              label="PASSWORD"
              value={form.password}
              onChangeText={v => setForm(f => ({ ...f, password: v }))}
              placeholder="Enter your password"
              secureTextEntry={!showPass}
              icon="🔒"
              error={errors.password}
            />

            <TouchableOpacity
              style={styles.showPassRow}
              onPress={() => setShowPass(s => !s)}
            >
              <Text style={styles.showPassText}>{showPass ? '🙈 Hide' : '👁 Show'} Password</Text>
            </TouchableOpacity>

            <GoldButton title="SIGN IN" onPress={handleLogin} loading={loading} style={styles.btn} />

            <TouchableOpacity style={styles.forgotRow}>
              <Text style={styles.forgotText}>Forgot Password?</Text>
            </TouchableOpacity>
          </View>

          {/* Register link */}
          <View style={styles.registerRow}>
            <Text style={styles.registerText}>Don't have an account? </Text>
            <TouchableOpacity onPress={() => navigation.navigate('Register')}>
              <Text style={styles.registerLink}>Register Now</Text>
            </TouchableOpacity>
          </View>

          {/* Trust badges */}
          <View style={styles.badges}>
            <Text style={styles.badge}>🔒 SSL Secured</Text>
            <Text style={styles.badgeDot}>•</Text>
            <Text style={styles.badge}>🏛 FBR Verified</Text>
            <Text style={styles.badgeDot}>•</Text>
            <Text style={styles.badge}>⚖️ SECP</Text>
          </View>

        </Animated.View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  scroll:        { flexGrow: 1 },
  container:     { flex: 1, paddingHorizontal: Spacing.lg, paddingTop: 70, paddingBottom: 40 },

  logoArea:      { alignItems: 'center', marginBottom: 36 },
  crest: {
    width: 80, height: 80, borderRadius: 16,
    alignItems: 'center', justifyContent: 'center',
    shadowColor: '#D4AF37', shadowOpacity: 0.5, shadowRadius: 16, elevation: 12,
    marginBottom: 14,
  },
  crestText:     { fontFamily: Typography.display, fontSize: 40, color: '#000' },
  brand:         { fontFamily: Typography.bold, fontSize: 18, color: Colors.gold, letterSpacing: 4 },
  subtitle:      { fontFamily: Typography.caption, fontSize: 12, color: Colors.textMuted, letterSpacing: 2, marginTop: 4 },

  card: {
    backgroundColor: Colors.backgroundCard,
    borderRadius: Radius.xl,
    padding: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.border,
    marginBottom: 24,
  },
  cardTitle:     { fontFamily: Typography.display, fontSize: 28, color: Colors.textPrimary, marginBottom: 6 },
  cardSub:       { fontFamily: Typography.body, fontSize: 14, color: Colors.textSecondary, marginBottom: 24 },

  errorBanner: {
    backgroundColor: Colors.dangerBg,
    borderWidth: 1,
    borderColor: Colors.danger,
    borderRadius: Radius.md,
    padding: 12,
    marginBottom: 16,
  },
  errorBannerText: { fontFamily: Typography.body, fontSize: 13, color: Colors.danger },

  showPassRow:   { alignItems: 'flex-end', marginTop: -8, marginBottom: 20 },
  showPassText:  { fontFamily: Typography.caption, fontSize: 12, color: Colors.textSecondary },
  btn:           { marginTop: 4 },

  forgotRow:     { alignItems: 'center', marginTop: 16 },
  forgotText:    { fontFamily: Typography.body, fontSize: 13, color: Colors.textSecondary },

  registerRow:   { flexDirection: 'row', justifyContent: 'center', marginBottom: 28 },
  registerText:  { fontFamily: Typography.body, fontSize: 14, color: Colors.textSecondary },
  registerLink:  { fontFamily: Typography.bold, fontSize: 14, color: Colors.gold },

  badges:        { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 8, flexWrap: 'wrap' },
  badge:         { fontFamily: Typography.caption, fontSize: 11, color: Colors.textMuted },
  badgeDot:      { color: Colors.goldDim },
});
