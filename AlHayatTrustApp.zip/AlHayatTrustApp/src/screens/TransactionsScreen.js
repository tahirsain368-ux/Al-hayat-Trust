// src/screens/TransactionsScreen.js
import React, { useState } from 'react';
import {
  View, Text, ScrollView, StyleSheet,
  TouchableOpacity, StatusBar,
} from 'react-native';
import { MOCK_DASHBOARD } from '../utils/api';
import { Card, Badge, EmptyState, GoldDivider } from '../components/UI';
import { Colors, Typography, Spacing, Radius } from '../utils/theme';

const FILTERS = ['All', 'Profit', 'Deposit', 'Withdrawal', 'Referral'];

const ALL_TX = [
  ...MOCK_DASHBOARD.recent_transactions,
  { id: 6,  type: 'profit',     amount: 450, date: '2026-05-31', status: 'completed', desc: 'Daily Profit' },
  { id: 7,  type: 'deposit',    amount: 5000, date: '2026-05-25', status: 'completed', desc: 'EasyPaisa Deposit' },
  { id: 8,  type: 'referral',   amount: 300, date: '2026-05-20', status: 'completed', desc: 'Referral Commission' },
  { id: 9,  type: 'withdrawal', amount: 3000, date: '2026-05-15', status: 'completed', desc: 'Withdrawal Approved' },
  { id: 10, type: 'profit',     amount: 450, date: '2026-05-14', status: 'completed', desc: 'Daily Profit' },
];

const TX_ICONS = { profit: '📈', deposit: '💳', withdrawal: '💸', referral: '👥' };
const TX_BADGE = { completed: 'success', pending: 'warning', rejected: 'danger' };

export default function TransactionsScreen({ navigation }) {
  const [filter, setFilter] = useState('All');

  const filtered = ALL_TX.filter(tx =>
    filter === 'All' || tx.type === filter.toLowerCase()
  );

  const totalIn  = filtered.filter(t => t.type !== 'withdrawal').reduce((s, t) => s + t.amount, 0);
  const totalOut = filtered.filter(t => t.type === 'withdrawal').reduce((s, t) => s + t.amount, 0);

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" />

      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.back}>
          <Text style={styles.backIcon}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Transactions</Text>
      </View>

      {/* Summary */}
      <View style={styles.summaryRow}>
        <Card style={styles.summaryCard}>
          <Text style={styles.summaryLabel}>Total In</Text>
          <Text style={[styles.summaryVal, { color: Colors.success }]}>+PKR {totalIn.toLocaleString()}</Text>
        </Card>
        <Card style={styles.summaryCard}>
          <Text style={styles.summaryLabel}>Total Out</Text>
          <Text style={[styles.summaryVal, { color: Colors.danger }]}>-PKR {totalOut.toLocaleString()}</Text>
        </Card>
      </View>

      {/* Filter tabs */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filterScroll} contentContainerStyle={styles.filterRow}>
        {FILTERS.map(f => (
          <TouchableOpacity key={f} onPress={() => setFilter(f)} style={[styles.filterTab, filter === f && styles.filterTabActive]}>
            <Text style={[styles.filterText, filter === f && styles.filterTextActive]}>{f}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <GoldDivider />

      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        {filtered.length === 0 ? (
          <EmptyState icon="📭" title="No transactions" subtitle={`No ${filter.toLowerCase()} transactions found`} />
        ) : (
          filtered.map(tx => (
            <Card key={tx.id} style={styles.txCard}>
              <View style={styles.txRow}>
                <View style={[styles.txIconWrap, { backgroundColor: tx.type === 'withdrawal' ? Colors.dangerBg : Colors.goldSubtle }]}>
                  <Text style={styles.txIcon}>{TX_ICONS[tx.type] || '💰'}</Text>
                </View>
                <View style={{ flex: 1, marginLeft: 12 }}>
                  <Text style={styles.txDesc}>{tx.desc}</Text>
                  <Text style={styles.txDate}>{tx.date}</Text>
                </View>
                <View style={{ alignItems: 'flex-end', gap: 4 }}>
                  <Text style={[styles.txAmount, { color: tx.type === 'withdrawal' ? Colors.danger : Colors.success }]}>
                    {tx.type === 'withdrawal' ? '-' : '+'}PKR {tx.amount.toLocaleString()}
                  </Text>
                  <Badge text={tx.status} type={TX_BADGE[tx.status]} />
                </View>
              </View>
            </Card>
          ))
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root:   { flex: 1, backgroundColor: Colors.backgroundDeep },
  header: { flexDirection: 'row', alignItems: 'center', paddingTop: 55, paddingHorizontal: Spacing.lg, paddingBottom: 12 },
  back:   { width: 40, height: 40, borderRadius: 20, backgroundColor: Colors.goldSubtle, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  backIcon: { fontSize: 20, color: Colors.gold },
  headerTitle: { fontFamily: Typography.display, fontSize: 24, color: Colors.textPrimary },

  summaryRow:  { flexDirection: 'row', gap: 12, paddingHorizontal: Spacing.lg, marginBottom: 12 },
  summaryCard: { flex: 1, alignItems: 'center' },
  summaryLabel:{ fontFamily: Typography.caption, fontSize: 11, color: Colors.textMuted, marginBottom: 4 },
  summaryVal:  { fontFamily: Typography.display, fontSize: 18 },

  filterScroll: { maxHeight: 50 },
  filterRow:    { paddingHorizontal: Spacing.lg, gap: 8, alignItems: 'center' },
  filterTab:    { paddingHorizontal: 16, paddingVertical: 8, borderRadius: Radius.full, borderWidth: 1, borderColor: Colors.border },
  filterTabActive: { backgroundColor: Colors.goldSubtle, borderColor: Colors.gold },
  filterText:   { fontFamily: Typography.heading, fontSize: 12, color: Colors.textSecondary },
  filterTextActive: { color: Colors.gold },

  scroll:  { padding: Spacing.lg, paddingBottom: 40 },
  txCard:  { marginBottom: 10 },
  txRow:   { flexDirection: 'row', alignItems: 'center' },
  txIconWrap:{ width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  txIcon:  { fontSize: 20 },
  txDesc:  { fontFamily: Typography.heading, fontSize: 14, color: Colors.textPrimary, marginBottom: 3 },
  txDate:  { fontFamily: Typography.caption, fontSize: 11, color: Colors.textMuted },
  txAmount:{ fontFamily: Typography.bold, fontSize: 14 },
});
