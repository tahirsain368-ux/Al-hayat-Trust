// src/screens/SplashScreen.js
import React, { useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, Animated, Dimensions, StatusBar,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, Typography } from '../utils/theme';

const { width, height } = Dimensions.get('window');

export default function SplashScreen({ navigation }) {
  const logoOpacity  = useRef(new Animated.Value(0)).current;
  const logoScale    = useRef(new Animated.Value(0.7)).current;
  const textOpacity  = useRef(new Animated.Value(0)).current;
  const lineWidth    = useRef(new Animated.Value(0)).current;
  const tagOpacity   = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.sequence([
      // Logo appears
      Animated.parallel([
        Animated.timing(logoOpacity, { toValue: 1, duration: 800, useNativeDriver: true }),
        Animated.spring(logoScale,   { toValue: 1, friction: 5,   useNativeDriver: true }),
      ]),
      // Divider line grows
      Animated.timing(lineWidth, { toValue: 120, duration: 600, useNativeDriver: false }),
      // Text fades in
      Animated.timing(textOpacity, { toValue: 1, duration: 500, useNativeDriver: true }),
      // Tagline
      Animated.timing(tagOpacity, { toValue: 1, duration: 500, useNativeDriver: true }),
      // Hold
      Animated.delay(1200),
    ]).start(() => {
      navigation.replace('Auth');
    });
  }, []);

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={Colors.backgroundDeep} />
      <LinearGradient
        colors={[Colors.backgroundDeep, '#0d0d1a', Colors.backgroundDeep]}
        style={StyleSheet.absoluteFillObject}
      />

      {/* Ambient glow */}
      <View style={styles.glow} />

      {/* Logo crest */}
      <Animated.View style={[styles.logoWrap, { opacity: logoOpacity, transform: [{ scale: logoScale }] }]}>
        <LinearGradient
          colors={['#F0CB5A', '#D4AF37', '#A88A20']}
          style={styles.crest}
        >
          <Text style={styles.crestText}>ح</Text>
        </LinearGradient>
      </Animated.View>

      {/* Divider */}
      <Animated.View style={[styles.divider, { width: lineWidth }]} />

      {/* Name */}
      <Animated.Text style={[styles.name, { opacity: textOpacity }]}>
        AL-HAYAT TRUST
      </Animated.Text>

      {/* Tagline */}
      <Animated.Text style={[styles.tagline, { opacity: tagOpacity }]}>
        Your Trusted Partner in Investment Success
      </Animated.Text>

      {/* Bottom badges */}
      <View style={styles.badges}>
        <Text style={styles.badge}>🏛 FBR Registered</Text>
        <Text style={styles.badgeDot}>•</Text>
        <Text style={styles.badge}>⚖️ SECP Compliant</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.backgroundDeep,
    alignItems: 'center',
    justifyContent: 'center',
  },
  glow: {
    position: 'absolute',
    width: 300,
    height: 300,
    borderRadius: 150,
    backgroundColor: 'rgba(212,175,55,0.06)',
    top: height / 2 - 200,
  },
  logoWrap: { marginBottom: 24 },
  crest: {
    width: 100,
    height: 100,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#D4AF37',
    shadowOpacity: 0.6,
    shadowRadius: 20,
    elevation: 16,
  },
  crestText: {
    fontFamily: Typography.display,
    fontSize: 52,
    color: '#000',
  },
  divider: {
    height: 1.5,
    backgroundColor: Colors.gold,
    marginBottom: 20,
    opacity: 0.7,
  },
  name: {
    fontFamily: Typography.bold,
    fontSize: 22,
    color: Colors.gold,
    letterSpacing: 6,
    marginBottom: 10,
  },
  tagline: {
    fontFamily: Typography.caption,
    fontSize: 13,
    color: Colors.textSecondary,
    letterSpacing: 1,
    textAlign: 'center',
    paddingHorizontal: 40,
  },
  badges: {
    position: 'absolute',
    bottom: 60,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  badge:    { fontFamily: Typography.caption, fontSize: 12, color: Colors.textMuted },
  badgeDot: { color: Colors.goldDim, fontSize: 16 },
});
