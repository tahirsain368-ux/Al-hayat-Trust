// src/utils/theme.js
export const Colors = {
  // Primary palette
  background:     '#0a0a0f',
  backgroundCard: '#111118',
  backgroundDeep: '#07070c',

  // Gold accent system
  gold:           '#D4AF37',
  goldLight:      '#F0CB5A',
  goldDim:        '#A88A20',
  goldSubtle:     'rgba(212,175,55,0.12)',
  goldBorder:     'rgba(212,175,55,0.25)',

  // Text
  textPrimary:    '#F5F0E8',
  textSecondary:  '#9A9080',
  textMuted:      '#5A5550',

  // Status
  success:        '#2ECC71',
  successBg:      'rgba(46,204,113,0.12)',
  danger:         '#E74C3C',
  dangerBg:       'rgba(231,76,60,0.12)',
  warning:        '#F39C12',
  warningBg:      'rgba(243,156,18,0.12)',
  info:           '#3498DB',
  infoBg:         'rgba(52,152,219,0.12)',

  // Borders
  border:         'rgba(212,175,55,0.15)',
  borderStrong:   'rgba(212,175,55,0.35)',

  // Overlay
  overlay:        'rgba(0,0,0,0.75)',
  overlayLight:   'rgba(0,0,0,0.4)',
};

export const Typography = {
  display: 'CormorantGaramond_700Bold',
  heading: 'Montserrat_600SemiBold',
  body:    'Montserrat_400Regular',
  caption: 'Montserrat_300Light',
  bold:    'Montserrat_700Bold',
};

export const Spacing = {
  xs:   4,
  sm:   8,
  md:   16,
  lg:   24,
  xl:   32,
  xxl:  48,
};

export const Radius = {
  sm:   6,
  md:   12,
  lg:   18,
  xl:   24,
  full: 999,
};

export const Shadow = {
  gold: {
    shadowColor:   '#D4AF37',
    shadowOffset:  { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius:  12,
    elevation:     8,
  },
  card: {
    shadowColor:   '#000',
    shadowOffset:  { width: 0, height: 8 },
    shadowOpacity: 0.45,
    shadowRadius:  16,
    elevation:     12,
  },
};
