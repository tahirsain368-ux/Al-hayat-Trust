// src/utils/api.js
import AsyncStorage from '@react-native-async-storage/async-storage';

const BASE_URL = 'https://www.alhayattrust.digital';

class ApiClient {
  constructor() {
    this.baseURL = BASE_URL;
  }

  async getHeaders(withAuth = true) {
    const headers = {
      'Content-Type': 'application/json',
      'Accept':       'application/json',
      'X-App-Client': 'mobile',
    };
    if (withAuth) {
      const token = await AsyncStorage.getItem('auth_token');
      if (token) headers['Authorization'] = `Bearer ${token}`;
    }
    return headers;
  }

  async request(method, endpoint, data = null, withAuth = true) {
    const headers = await this.getHeaders(withAuth);
    const config  = { method, headers };

    if (data && method !== 'GET') {
      config.body = JSON.stringify(data);
    }

    const url = `${this.baseURL}${endpoint}`;
    try {
      const response = await fetch(url, config);
      const json     = await response.json();
      if (!response.ok) {
        throw new Error(json.message || `HTTP ${response.status}`);
      }
      return json;
    } catch (error) {
      throw error;
    }
  }

  // Auth endpoints
  login    = (data)  => this.request('POST', '/api/auth/login.php', data, false);
  register = (data)  => this.request('POST', '/api/auth/register.php', data, false);
  logout   = ()      => this.request('POST', '/api/auth/logout.php');

  // Dashboard
  getDashboard  = ()   => this.request('GET',  '/api/user/dashboard.php');
  getProfile    = ()   => this.request('GET',  '/api/user/profile.php');
  updateProfile = (d)  => this.request('POST', '/api/user/profile.php', d);

  // Plans
  getPlans = () => this.request('GET', '/api/plans/list.php');
  invest   = (d) => this.request('POST', '/api/plans/invest.php', d);

  // Deposits
  getDeposits    = () => this.request('GET', '/api/deposits/list.php');
  createDeposit  = (d) => this.request('POST', '/api/deposits/create.php', d);

  // Withdrawals
  getWithdrawals   = () => this.request('GET', '/api/withdrawals/list.php');
  createWithdrawal = (d) => this.request('POST', '/api/withdrawals/create.php', d);

  // Referrals
  getReferrals    = () => this.request('GET', '/api/referrals/list.php');
  getReferralCode = () => this.request('GET', '/api/referrals/code.php');

  // Notifications
  getNotifications  = () => this.request('GET',  '/api/notifications/list.php');
  markNotifRead     = (id) => this.request('POST', '/api/notifications/read.php', { id });

  // Transactions
  getTransactions = (params = '') => this.request('GET', `/api/transactions/list.php${params}`);

  // Ranks
  getRanks = () => this.request('GET', '/api/ranks/list.php');
}

export const api = new ApiClient();

// Mock data for offline/demo mode
export const MOCK_DASHBOARD = {
  user: {
    id: 1,
    name: 'Ahmed Khan',
    username: 'ahmedkhan',
    email: 'ahmed@example.com',
    phone: '03001234567',
    referral_code: 'AHK2024',
    rank: 'Silver',
    avatar: null,
  },
  balance: {
    main:       25000,
    profit:     3750,
    referral:   1200,
    withdrawn:  8000,
    total_invested: 20000,
  },
  stats: {
    total_deposits:    3,
    active_plans:      2,
    total_referrals:   7,
    today_profit:      450,
  },
  chart_data: [
    { date: '01 Jun', amount: 21000 },
    { date: '02 Jun', amount: 21450 },
    { date: '03 Jun', amount: 21900 },
    { date: '04 Jun', amount: 22800 },
    { date: '05 Jun', amount: 23500 },
    { date: '06 Jun', amount: 24200 },
    { date: '07 Jun', amount: 25000 },
  ],
  recent_transactions: [
    { id: 1, type: 'profit',    amount: 450,   date: '2026-06-07', status: 'completed', desc: 'Daily Profit' },
    { id: 2, type: 'deposit',   amount: 5000,  date: '2026-06-05', status: 'completed', desc: 'JazzCash Deposit' },
    { id: 3, type: 'referral',  amount: 300,   date: '2026-06-04', status: 'completed', desc: 'Referral Bonus' },
    { id: 4, type: 'withdrawal',amount: 2000,  date: '2026-06-02', status: 'pending',   desc: 'Withdrawal Request' },
    { id: 5, type: 'profit',    amount: 450,   date: '2026-06-01', status: 'completed', desc: 'Daily Profit' },
  ],
};

export const MOCK_PLANS = [
  { id: 1, name: 'Starter',    min: 1000,  max: 9999,   daily_profit: 1.5, duration: 30, total_return: 45,  color: '#C0C0C0' },
  { id: 2, name: 'Silver',     min: 10000, max: 49999,  daily_profit: 2.5, duration: 30, total_return: 75,  color: '#D4AF37' },
  { id: 3, name: 'Gold',       min: 50000, max: 149999, daily_profit: 3.5, duration: 30, total_return: 105, color: '#FFD700' },
  { id: 4, name: 'Platinum',   min: 150000,max: 499999, daily_profit: 5.0, duration: 30, total_return: 150, color: '#E5E4E2' },
  { id: 5, name: 'Diamond',    min: 500000,max: null,   daily_profit: 7.0, duration: 30, total_return: 210, color: '#B9F2FF' },
];
