# 📱 Al-Hayat Trust — React Native / Expo App

A full-featured mobile investment platform app for Android (APK) and iOS (IPA).

---

## 🚀 Quick Start

### Prerequisites
- **Node.js** v18+ → https://nodejs.org
- **Expo CLI** → `npm install -g expo-cli eas-cli`
- **Android Studio** (for Android emulator) OR a physical Android device
- **Xcode** (iOS, Mac only)

---

## 📦 Step 1: Install Dependencies

```bash
cd AlHayatTrustApp
npm install
```

---

## ▶️ Step 2: Run on Your Phone (Instant Preview)

### Option A — Expo Go App (Fastest, no build needed)
1. Install **Expo Go** from Play Store or App Store on your phone
2. Run:
   ```bash
   npx expo start
   ```
3. Scan the QR code with Expo Go → App opens instantly!

### Option B — Android Emulator
```bash
npx expo start --android
```

### Option C — iOS Simulator (Mac only)
```bash
npx expo start --ios
```

---

## 🏗️ Step 3: Build Real APK (Android)

### Using EAS Build (Recommended — Free)

```bash
# 1. Login to Expo account (free signup at expo.dev)
eas login

# 2. Configure your project
eas build:configure

# 3. Build APK for testing
eas build --platform android --profile preview
```

✅ This builds in the **cloud** — no Android Studio needed!
After ~5–10 minutes, you get a **download link for your APK**.

### Using Local Build (Android Studio required)
```bash
# Generate Android project files
npx expo prebuild --platform android

# Build APK locally
cd android
./gradlew assembleRelease

# APK will be at:
# android/app/build/outputs/apk/release/app-release.apk
```

---

## 🍎 Step 4: Build iOS IPA

```bash
# Using EAS (Mac not required!)
eas build --platform ios --profile preview

# OR for App Store
eas build --platform ios --profile production
```

**Note:** iOS distribution requires an Apple Developer account ($99/year).
For testing without a developer account, use **TestFlight** or the iOS Simulator.

---

## 📤 Step 5: Install APK on Android

After EAS build completes:
1. Download the `.apk` file from the link provided
2. Transfer to your Android phone (WhatsApp, USB, Google Drive)
3. Enable **"Install from Unknown Sources"** in phone settings
4. Tap the APK to install

---

## 🌐 Connecting to Your Backend

Edit `src/utils/api.js`:
```js
const BASE_URL = 'https://www.alhayattrust.digital'; // ← Your domain
```

The app automatically falls back to **demo/mock data** if the API is unreachable.

### Required API Endpoints
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/auth/login.php` | POST | Login |
| `/api/auth/register.php` | POST | Register |
| `/api/user/dashboard.php` | GET | Dashboard data |
| `/api/plans/list.php` | GET | Investment plans |
| `/api/deposits/create.php` | POST | Submit deposit |
| `/api/withdrawals/create.php` | POST | Submit withdrawal |
| `/api/referrals/list.php` | GET | My referrals |
| `/api/transactions/list.php` | GET | Transactions |

---

## 📱 App Features

| Screen | Features |
|--------|----------|
| **Splash** | Animated logo, brand intro |
| **Login** | Username/phone + password, demo mode |
| **Register** | 2-step form, referral code support |
| **Dashboard** | Balance card, growth chart, stats, quick actions |
| **Plans** | All investment plans, profit calculator, invest modal |
| **Deposit** | JazzCash, EasyPaisa, Bank Transfer support |
| **Withdraw** | Multi-method, fee calculator, balance check |
| **Referral** | Copy code/link, share, 3-level commission display |
| **Transactions** | Full history, filter by type |
| **Profile** | Account info, settings, logout |

---

## 🎨 Design System

- **Colors:** Dark navy (#0a0a0f) + Gold (#D4AF37)
- **Fonts:** Cormorant Garamond (display) + Montserrat (body)
- **Theme:** Luxury fintech, matches Al-Hayat Trust website

---

## 🔧 Project Structure

```
AlHayatTrustApp/
├── App.js                    # Entry point
├── app.json                  # Expo config
├── eas.json                  # Build profiles
├── src/
│   ├── screens/
│   │   ├── SplashScreen.js
│   │   ├── LoginScreen.js
│   │   ├── RegisterScreen.js
│   │   ├── HomeScreen.js
│   │   ├── PlansScreen.js
│   │   ├── DepositScreen.js
│   │   ├── WithdrawScreen.js
│   │   ├── ReferralScreen.js
│   │   ├── TransactionsScreen.js
│   │   └── ProfileScreen.js
│   ├── components/
│   │   └── UI.js             # Reusable components
│   ├── navigation/
│   │   └── AppNavigator.js   # Navigation setup
│   ├── context/
│   │   └── AuthContext.js    # Auth state
│   └── utils/
│       ├── api.js            # API client + mock data
│       └── theme.js          # Design tokens
```

---

## 🆘 Common Issues

**"Metro bundler not starting"**
```bash
npx expo start --clear
```

**"Module not found"**
```bash
rm -rf node_modules
npm install
```

**EAS build fails**
```bash
eas build:cancel
eas build --platform android --profile preview --clear-cache
```

---

## 📞 Support

WhatsApp: 0300-1234567  
Website: https://www.alhayattrust.digital  
Email: support@alhayattrust.digital

---

**Built with ❤️ in Pakistan 🇵🇰**  
Al-Hayat Trust · FBR Registered · SECP Compliant
